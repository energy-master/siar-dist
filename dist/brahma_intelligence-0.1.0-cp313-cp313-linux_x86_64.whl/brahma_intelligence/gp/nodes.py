# Vixen Intelligence c.2026
"""The function set: what an evolved expression is allowed to say.

The function set is the vocabulary of the search. Too small and the metric you want is
unreachable; too large and the search space explodes and every tree becomes unreadable. This one
is deliberately modest — fourteen functions — and every member earns its place:

* ``add sub mul pdiv`` — arithmetic. Ratios matter more than sums for acoustic features, which is
  why ``pdiv`` is in the default weighting at all rather than being an exotic.
* ``neg abs`` — sign handling, so the GA does not have to encode "distance from" as a subtraction
  it then squares.
* ``plog psqrt square`` — compression and expansion. Band energies span orders of magnitude even
  after the frontend's ``log1p``.
* ``tanh expneg`` — bounded squashes. These are how an expression says "saturate", which is what
  a detector fundamentally does.
* ``min max`` — order statistics, and the building blocks of "the larger of these two bands".
* ``if_gt`` — conditional behaviour without leaving the float type system.

**Deliberately absent:** raw ``/``, ``log``, ``exp``, ``pow``. Every one has a domain hole, and a
GP population finds domain holes immediately and exploits them, because ``inf`` and ``nan``
propagate to a fitness that is either always or never selected. See
:mod:`~brahma_intelligence.gp.primitives`.

``arg_types`` and ``ret_type`` are ``FLOAT`` on every entry today. They exist so that
strongly-typed GP — where a node could consume a *vector* of band energies and return a scalar —
becomes a change to tree *generation* and not a change to the serialised format. That matters
because saved models must keep loading.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from ..errors import ConfigError
from . import primitives as p

__all__ = ["FLOAT", "FUNCTIONS", "FunctionDef", "arity_of", "kernel_of"]

#: The only type in v0.1. See the module docstring.
FLOAT = "float"


@dataclass(frozen=True, slots=True)
class FunctionDef:
    """One entry in the function set.

    Attributes:
        name: The op string. This is what appears in the serialised JSON, so renaming one breaks
            every saved model — treat it as part of the file format.
        arity: How many arguments it takes.
        kernel: The numpy implementation. Must be total and out-of-place; see
            :mod:`~brahma_intelligence.gp.primitives`.
        doc: One line, shown by the CLI and the README.
        infix: Optional infix template for rendering, e.g. ``"{0} + {1}"``. Functions without one
            render as ``name(args...)``.
        commutative: Whether argument order is irrelevant. Used for structural comparison and,
            later, for simplification.
        arg_types: Per-argument type. All ``FLOAT`` in v0.1.
        ret_type: Return type. ``FLOAT`` in v0.1.
    """

    name: str
    arity: int
    kernel: Callable
    doc: str
    infix: str | None = None
    commutative: bool = False
    arg_types: tuple[str, ...] = field(default=())
    ret_type: str = FLOAT

    def __post_init__(self) -> None:
        if not self.arg_types:
            object.__setattr__(self, "arg_types", (FLOAT,) * self.arity)
        if len(self.arg_types) != self.arity:
            raise ConfigError(f"{self.name}: {len(self.arg_types)} arg types for arity {self.arity}")


def _f(*args, **kwargs) -> tuple[str, FunctionDef]:
    d = FunctionDef(*args, **kwargs)
    return d.name, d


#: The function set, keyed by op string. A plain dict, because the *only* thing that ever crosses
#: from a serialised program into executable code is a string used as a key here — see
#: :mod:`~brahma_intelligence.gp.serialise` for why that is the whole safety argument.
FUNCTIONS: dict[str, FunctionDef] = dict(
    [
        _f("add", 2, p.k_add, "a + b", infix="{0} + {1}", commutative=True),
        _f("sub", 2, p.k_sub, "a - b", infix="{0} - {1}"),
        _f("mul", 2, p.k_mul, "a * b", infix="{0} * {1}", commutative=True),
        _f("pdiv", 2, p.pdiv, "protected a / b (1.0 when |b| is tiny)", infix="{0} / {1}"),
        _f("neg", 1, p.k_neg, "-a", infix="-{0}"),
        _f("abs", 1, p.k_abs, "|a|"),
        _f("plog", 1, p.plog, "log1p(|a|) — compress a wide dynamic range"),
        _f("psqrt", 1, p.psqrt, "sqrt(|a|)"),
        _f("square", 1, p.square, "a * a"),
        _f("tanh", 1, p.k_tanh, "tanh(a) — bounded squash into (-1, 1)"),
        _f("expneg", 1, p.expneg, "exp(-|a|) — bounded in (0, 1], cannot overflow"),
        _f("min", 2, p.k_min, "elementwise min(a, b)", commutative=True),
        _f("max", 2, p.k_max, "elementwise max(a, b)", commutative=True),
        _f("if_gt", 4, p.if_gt, "c if a > b else d — conditionals without leaving float"),
        # Fuzzy group — present in the table so a model built with them always loads, but not
        # offered to the search unless it was asked for. See ACTIVE_GROUPS below.
        _f("fnot", 1, p.fnot, "1 - a — fuzzy complement"),
        _f("probor", 2, p.probor, "a + b - a*b — soft or, evidence that accumulates",
           commutative=True),
        _f("fgauss", 2, p.fgauss, "exp(-(a-b)^2) — degree to which a is near b",
           commutative=True),
        _f("fsgt", 2, p.fsgt, "0.5(1 + tanh(a-b)) — graded a > b, if_gt without the cliff"),
        _f("fimp", 2, p.fimp, "min(1, 1-a+b) — Lukasiewicz implication, a rule in a tree"),
    ]
)

#: The arithmetic set, and what every society before the fuzzy group was bred with.
CORE_OPS: tuple[str, ...] = (
    "abs", "add", "expneg", "if_gt", "max", "min", "mul", "neg",
    "pdiv", "plog", "psqrt", "square", "sub", "tanh",
)

#: Graded logic. Opt-in: see :func:`set_active_groups`.
FUZZY_OPS: tuple[str, ...] = ("fgauss", "fimp", "fnot", "fsgt", "probor")

#: Named groups a run may draw its function set from.
OP_GROUPS: dict[str, tuple[str, ...]] = {"core": CORE_OPS, "fuzzy": FUZZY_OPS}

_ACTIVE_GROUPS: tuple[str, ...] = ("core",)


def set_active_groups(*groups: str) -> tuple[str, ...]:
    """Choose which function groups the search may draw from.

    Two things depend on this being explicit rather than "everything in the table".

    **Reproducibility.** A tree is grown by indexing into the sorted op names, so adding an op
    shifts the meaning of every random draw after it. A society replayed at its own seed must
    breed the same bots it bred before, which it only does if the set it drew from is the set it
    drew from then. Adding the fuzzy group to the table therefore does not add it to the search:
    with the default ``("core",)`` the names offered are exactly the fourteen that were offered
    before it existed.

    **Loading is not evolving.** :data:`FUNCTIONS` always holds every op, so a model bred with the
    fuzzy group runs anywhere — including on a scanner that would never breed one. Only the
    *search* is gated.

    Args:
        groups: Names from :data:`OP_GROUPS`. ``set_active_groups("core", "fuzzy")`` offers both.

    Returns:
        The active op names, sorted.

    Raises:
        ConfigError: On an unknown group name.
    """
    global _ACTIVE_GROUPS
    if not groups:
        groups = ("core",)
    unknown = [g for g in groups if g not in OP_GROUPS]
    if unknown:
        raise ConfigError(
            f"unknown function group(s) {unknown}; known: {', '.join(sorted(OP_GROUPS))}")
    _ACTIVE_GROUPS = tuple(groups)
    return active_ops()


def active_ops() -> tuple[str, ...]:
    """The function ops the search may draw from, sorted.

    Sorted, not group order, because the choice consumes randomness — the same reason
    :func:`~brahma_intelligence.gp.generate._function_names` sorted before this existed.
    """
    names: set[str] = set()
    for g in _ACTIVE_GROUPS:
        names.update(OP_GROUPS[g])
    return tuple(sorted(names))


def active_groups() -> tuple[str, ...]:
    """Which groups are switched on, for a run to record against itself."""
    return _ACTIVE_GROUPS

#: Terminal ops. Not in :data:`FUNCTIONS` because they carry data (an index, a value) rather than
#: a kernel, and the evaluator dispatches them before it consults the function table.
TERMINALS = ("feature", "const")


def arity_of(op: str) -> int:
    """The arity of an op, terminals included.

    Args:
        op: An op string.

    Returns:
        0 for terminals, otherwise the function's arity.

    Raises:
        ConfigError: If the op is unknown.
    """
    if op in TERMINALS:
        return 0
    try:
        return FUNCTIONS[op].arity
    except KeyError:
        raise ConfigError(f"unknown op {op!r}; known: {', '.join(sorted(FUNCTIONS))}") from None


def kernel_of(op: str) -> Callable:
    """The numpy kernel for a function op.

    Args:
        op: An op string naming a function (not a terminal).

    Returns:
        The kernel.

    Raises:
        ConfigError: If the op is unknown or is a terminal.
    """
    try:
        return FUNCTIONS[op].kernel
    except KeyError:
        raise ConfigError(f"unknown function op {op!r}") from None


def describe_functions() -> list[tuple[str, str]]:
    """``(name, doc)`` for every function, sorted — what the CLI prints."""
    return [(n, FUNCTIONS[n].doc) for n in sorted(FUNCTIONS)]
