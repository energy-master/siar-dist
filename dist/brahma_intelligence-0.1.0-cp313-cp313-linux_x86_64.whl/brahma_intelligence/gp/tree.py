# Vixen Intelligence c.2026
"""The genome: an immutable expression tree.

**One canonical representation.** There is no separate "compiled" form, no cached closure, no
bytecode. A :class:`Node` is exactly what gets serialised and exactly what gets evaluated. The
alternative — a fast internal form plus a JSON form — means a genome has two sources of truth
about what it computes, and the failure mode is a champion that scores 0.94 during the run and
0.87 when reloaded, with nothing in either code path obviously wrong.

**Frozen and hashable**, which buys three things for free: subtree results can be memoised in a
dict keyed by node (v0.2); distinct-individual counting, the diversity-collapse signal, is a
``set`` of roots; and no operator can accidentally mutate a shared subtree, because crossover
splices the *same* node objects into both children.

Node addressing is by pre-order index, so "subtree 7" means the same thing to crossover, mutation
and hoisting. :func:`subtree_indices` and :func:`replace_at` are the only two primitives any
operator needs.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator

from ..errors import ProgramError
from .nodes import FUNCTIONS, arity_of

__all__ = [
    "Node",
    "const",
    "depth",
    "feature",
    "feature_indices",
    "iter_nodes",
    "node_at",
    "render",
    "replace_at",
    "size",
    "subtree_indices",
    "validate",
]


@dataclass(frozen=True, slots=True)
class Node:
    """One node of an expression tree.

    Attributes:
        op: A key into :data:`~brahma_intelligence.gp.nodes.FUNCTIONS`, or ``"feature"`` or
            ``"const"``.
        args: Children. ``len(args)`` must equal the op's arity; empty for terminals.
        index: Feature index, for ``"feature"`` nodes only. Authoritative — the name carried in
            the JSON is for humans, and is verified against the model's feature list on load
            rather than trusted.
        value: The constant, for ``"const"`` nodes only.
    """

    op: str
    args: tuple["Node", ...] = ()
    index: int | None = None
    value: float | None = None

    def __str__(self) -> str:
        return render(self)


def feature(index: int) -> Node:
    """A feature terminal.

    Args:
        index: Column in the feature vector.

    Returns:
        The node.
    """
    return Node(op="feature", index=int(index))


def const(value: float) -> Node:
    """A constant terminal.

    Args:
        value: The constant. Must be finite — an ``inf`` constant would poison every score it
            touches and no amount of downstream clipping recovers the information.

    Returns:
        The node.

    Raises:
        ProgramError: If ``value`` is not finite.
    """
    v = float(value)
    if v != v or v in (float("inf"), float("-inf")):
        raise ProgramError(f"constant must be finite, got {value!r}")
    return Node(op="const", value=v)


def iter_nodes(node: Node) -> Iterator[Node]:
    """Every node, pre-order (root first, then each child's subtree in order).

    Pre-order is the addressing convention throughout: index ``i`` from this iteration is the
    same node :func:`node_at` and :func:`replace_at` mean by ``i``.

    Args:
        node: The root.

    Yields:
        Each node.
    """
    stack = [node]
    while stack:
        n = stack.pop()
        yield n
        stack.extend(reversed(n.args))


def size(node: Node) -> int:
    """Total node count — the unit bloat is measured in.

    Args:
        node: The root.

    Returns:
        The number of nodes.
    """
    return 1 + sum(size(a) for a in node.args)


def depth(node: Node) -> int:
    """Longest root-to-leaf path, counting the root as depth 1.

    Args:
        node: The root.

    Returns:
        The depth.
    """
    return 1 + max((depth(a) for a in node.args), default=0)


def node_at(root: Node, i: int) -> Node:
    """The node at pre-order index ``i``.

    Args:
        root: The tree root.
        i: Pre-order index.

    Returns:
        The node.

    Raises:
        IndexError: If ``i`` is out of range.
    """
    for j, n in enumerate(iter_nodes(root)):
        if j == i:
            return n
    raise IndexError(f"node index {i} out of range for tree of size {size(root)}")


def subtree_indices(root: Node) -> tuple[list[int], list[int]]:
    """Split node indices into internal (function) and leaf (terminal) positions.

    Koza's 90/10 rule biases crossover towards internal nodes, because cutting at a leaf swaps
    one terminal for another and mostly does nothing. Implementing that needs the two index sets,
    and computing them once per operator call beats filtering inside a loop.

    Args:
        root: The tree root.

    Returns:
        ``(internal_indices, leaf_indices)``. Either may be empty — a single-terminal tree has no
        internal nodes at all, which operators must handle rather than assume away.
    """
    internal: list[int] = []
    leaf: list[int] = []
    for i, n in enumerate(iter_nodes(root)):
        (internal if n.args else leaf).append(i)
    return internal, leaf


def replace_at(root: Node, i: int, replacement: Node) -> Node:
    """A copy of ``root`` with the node at pre-order index ``i`` replaced.

    Structural sharing: every subtree not on the path from the root to ``i`` is reused, not
    copied. Nodes are immutable, so that is safe, and it is what keeps crossover cheap on deep
    trees.

    Args:
        root: The tree root.
        i: Pre-order index of the node to replace.
        replacement: The new subtree.

    Returns:
        The new root.

    Raises:
        IndexError: If ``i`` is out of range.
    """
    counter = [0]

    def walk(n: Node) -> Node:
        here = counter[0]
        counter[0] += 1
        if here == i:
            # Skip over the replaced subtree's indices so siblings still address correctly.
            counter[0] = here + size(n)
            return replacement
        if not n.args:
            return n
        return Node(op=n.op, args=tuple(walk(a) for a in n.args), index=n.index, value=n.value)

    total = size(root)
    if not 0 <= i < total:
        raise IndexError(f"node index {i} out of range for tree of size {total}")
    return walk(root)


def feature_indices(node: Node) -> list[int]:
    """Every distinct feature index the tree reads, sorted.

    This is the *scientific* readout of a run. "Did the champion reference the band containing the
    tone we planted?" is the question the self-test asks, and asking it of the expression string
    would be brittle — there are thousands of equivalent trees. Asking it of the index set is not.

    Args:
        node: The root.

    Returns:
        Sorted distinct feature indices; empty if the tree is all constants.
    """
    return sorted({n.index for n in iter_nodes(node) if n.op == "feature" and n.index is not None})


def render(node: Node, names: list[str] | None = None) -> str:
    """The tree as a readable infix expression.

    Always re-derived from the tree, never stored and reloaded. A cached string can drift out of
    step with the structure it claims to describe, and a *lie* about what a champion computes is
    worse than no description at all.

    Args:
        node: The root.
        names: Feature names, so terminals render as ``band_2400_2600`` rather than ``f12``.
            Falls back to ``f<index>`` when absent or too short.

    Returns:
        The expression. Parenthesised enough to be unambiguous, not minimally.
    """
    if node.op == "const":
        v = float(node.value if node.value is not None else 0.0)
        return f"{v:g}"
    if node.op == "feature":
        i = int(node.index or 0)
        if names is not None and 0 <= i < len(names):
            return names[i]
        return f"f{i}"
    fn = FUNCTIONS.get(node.op)
    parts = [render(a, names) for a in node.args]
    if fn is not None and fn.infix is not None:
        return "(" + fn.infix.format(*parts) + ")"
    return f"{node.op}(" + ", ".join(parts) + ")"


def validate(node: Node) -> None:
    """Check a tree is structurally sound.

    Args:
        node: The root.

    Raises:
        ProgramError: On an unknown op, an arity mismatch, a terminal missing its payload, or a
            non-finite constant. Called after deserialisation, where the input is data from disk
            rather than something this process built.
    """
    for n in iter_nodes(node):
        if n.op == "feature":
            if n.index is None or n.index < 0:
                raise ProgramError(f"feature node needs a non-negative index, got {n.index!r}")
            if n.args:
                raise ProgramError("feature node must have no arguments")
        elif n.op == "const":
            v = n.value
            if v is None or v != v or v in (float("inf"), float("-inf")):
                raise ProgramError(f"const node needs a finite value, got {v!r}")
            if n.args:
                raise ProgramError("const node must have no arguments")
        else:
            want = arity_of(n.op)
            if len(n.args) != want:
                raise ProgramError(
                    f"op {n.op!r} takes {want} arguments, got {len(n.args)}"
                )
