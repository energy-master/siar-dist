# Vixen Intelligence c.2026
"""Evaluating trees over every window at once.

**The data contract**, stated the way ``brahma_lib/include/brahma/grid.hpp`` states bin-major:

    ``F`` is ``(n_features, n_windows)``, float64, C-contiguous. ``F[i]`` is therefore a
    **contiguous** view of feature ``i`` across every window.

That transpose is not cosmetic. The natural layout coming out of feature extraction is
``(n_windows, n_features)``, on which ``X[:, i]`` is a strided gather. A tree touches feature
columns tens of thousands of times per generation, so the dataset transposes once at build time
and every evaluation reads contiguous memory thereafter.

Three rules the implementation depends on:

1. **Constant subtrees return a bare Python float, not an array.** numpy broadcasts scalars for
   free; materialising ``np.full(n_windows, 0.25)`` for every constant terminal is thousands of
   pointless allocations per generation. Only :func:`evaluate_root` promotes to a full array, and
   only at the very end.
2. **Sanitisation happens once, in the dispatcher.** ``nan_to_num`` plus a magnitude clip, applied
   to every node's result. Putting it in each kernel means the day someone adds a primitive and
   forgets, an ``inf`` escapes into a fitness and the run silently breaks.
3. **Kernels never write in place.** A feature terminal hands back a view into ``F``; writing
   through it would corrupt the dataset for every individual evaluated afterwards.

Why plain recursion is fast enough: the cost is dominated by numpy call overhead on
few-thousand-element arrays, not by Python frame overhead. A 30-node tree is 30 numpy calls at
roughly 5-20 µs each; a 300-individual generation is therefore a fraction of a second, and 60
generations of that is well inside a coffee break. Optimising the traversal before the arrays get
much bigger would be optimising the wrong thing.
"""
from __future__ import annotations

from typing import Sequence

import numpy as np

from ..errors import ProgramError
from .nodes import FUNCTIONS
from .tree import Node

__all__ = ["CLIP", "evaluate", "evaluate_population", "evaluate_root"]

#: Magnitude beyond which values saturate. Chosen well above any plausible standardised feature
#: combination and well below float64's range, so ``square(square(square(x)))`` clips instead of
#: reaching ``inf`` and taking the fitness with it.
CLIP = 1e6


def _sanitise(v):
    """Clamp one node's result into a finite, bounded range.

    The single choke point for numerical hygiene. ``nan`` becomes 0.0 rather than propagating,
    because a ``nan`` that reaches the objective makes the individual's fitness undefined and
    therefore unselectable — which is the right outcome for a genuinely undefined *objective*,
    but the wrong one for a transient intermediate that a later ``abs`` would have fixed.
    """
    if np.isscalar(v):
        f = float(v)
        if f != f:
            return 0.0
        return float(np.clip(f, -CLIP, CLIP))
    out = np.nan_to_num(v, nan=0.0, posinf=CLIP, neginf=-CLIP)
    return np.clip(out, -CLIP, CLIP)


def evaluate(node: Node, F: np.ndarray):
    """Evaluate one tree over every window at once.

    Args:
        node: The tree root.
        F: ``(n_features, n_windows)`` feature-major float64. See the module docstring.

    Returns:
        ``(n_windows,)`` float64, or a bare Python float when the whole subtree is constant.
        Never contains ``nan`` or ``inf``.

    Raises:
        ProgramError: On an unknown op or a feature index outside ``F``. Both mean a tree was
            built against a different feature set, which must fail loudly — a silently
            out-of-range index would otherwise read a neighbouring feature and produce a
            confident, wrong number.
    """
    # Overflow and invalid-value warnings are *expected* here, not exceptional: a GP population
    # routinely builds square(square(square(x))) and numpy is right that it overflowed. The
    # dispatcher clips the result on the very next line, so the condition is handled — but a
    # warning per node per individual per generation is either a wall of noise or, under
    # `-W error` or pytest's filterwarnings, a crash mid-run. Silence them here, where the
    # handling is, rather than globally.
    with np.errstate(over="ignore", invalid="ignore", divide="ignore", under="ignore"):
        return _eval(node, F)


def _eval(node: Node, F: np.ndarray):
    """The recursive worker. See :func:`evaluate`, which supplies the error state."""
    op = node.op
    if op == "const":
        return float(node.value if node.value is not None else 0.0)
    if op == "feature":
        i = int(node.index or 0)
        if not 0 <= i < F.shape[0]:
            raise ProgramError(
                f"feature index {i} out of range for {F.shape[0]} features — this program was "
                f"evolved against a different feature set"
            )
        return F[i]

    fn = FUNCTIONS.get(op)
    if fn is None:
        raise ProgramError(f"unknown op {op!r}")
    args = [_eval(a, F) for a in node.args]
    return _sanitise(fn.kernel(*args))


def evaluate_root(node: Node, F: np.ndarray) -> np.ndarray:
    """Evaluate a tree and always return a full ``(n_windows,)`` array.

    The promotion point for constant trees. They are common in generation 0 and are exactly what
    ROC-AUC's tie handling is there to catch: a constant score ties every pair and scores an
    honest 0.5, not a flattering 1.0.

    Args:
        node: The tree root.
        F: ``(n_features, n_windows)`` feature-major float64.

    Returns:
        ``(n_windows,)`` float64.
    """
    v = evaluate(node, F)
    if np.isscalar(v):
        return np.full(F.shape[1], float(v), dtype=np.float64)
    return np.ascontiguousarray(v, dtype=np.float64)


def evaluate_population(trees: Sequence[Node], F: np.ndarray) -> np.ndarray:
    """Evaluate a whole population.

    Args:
        trees: The population's roots.
        F: ``(n_features, n_windows)`` feature-major float64.

    Returns:
        ``(pop_size, n_windows)`` float64 — the score matrix the objectives consume, and the
        phenotype matrix diversity measures consume.
    """
    n = F.shape[1]
    out = np.empty((len(trees), n), dtype=np.float64)
    for i, t in enumerate(trees):
        out[i] = evaluate_root(t, F)
    return out
