# Vixen Intelligence c.2026
"""The numpy kernels behind the function set.

Two rules govern everything here, and both are load-bearing.

**Every kernel is total.** No domain holes. Division by zero, ``log`` of a negative, ``exp`` of
600 — each produces ``inf`` or ``nan``, and one ``nan`` anywhere in a score vector turns that
individual's fitness into ``nan``. Depending on how the comparison falls, such an individual then
either always or never wins a tournament, and either way the run is quietly broken while looking
completely normal. Rather than sanitise after the fact, the primitives are chosen so the hole
does not exist: ``pdiv`` guards its denominator, ``plog`` takes ``log1p(|x|)``, ``psqrt`` takes
``sqrt(|x|)``, and there is no unprotected ``exp`` or ``pow`` in the set at all.

**Every kernel is out-of-place.** A feature terminal returns a *view* into the dataset's feature
matrix. An in-place kernel would therefore write through that view and corrupt the features for
every individual evaluated afterwards — a bug that shows up as fitness drifting between
generations for no reason anyone can find. No ``out=`` arguments, no ``+=``.

Sanitisation (``nan_to_num`` plus a magnitude clip) happens once, in the evaluation dispatcher,
not in each kernel. One place means it cannot be forgotten when a primitive is added.

Kernels accept scalars or arrays interchangeably, because a constant subtree evaluates to a bare
float and numpy broadcasts it for free — materialising a full array per constant would be pure
waste at population scale.
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "expneg",
    "fgauss",
    "fimp",
    "fnot",
    "fsgt",
    "if_gt",
    "k_abs",
    "k_add",
    "k_max",
    "k_min",
    "k_mul",
    "k_neg",
    "k_sub",
    "k_tanh",
    "pdiv",
    "plog",
    "probor",
    "psqrt",
    "square",
]

#: Below this magnitude a denominator counts as zero. Not ``0.0``: a denominator of 1e-300 is
#: numerically zero for our purposes and dividing by it produces an overflow that the clip then
#: has to mop up, which loses the information anyway.
DIV_EPS = 1e-9


def k_add(a, b):
    """``a + b``."""
    return a + b


def k_sub(a, b):
    """``a - b``."""
    return a - b


def k_mul(a, b):
    """``a * b``."""
    return a * b


def pdiv(a, b):
    """Protected division: ``a / b``, or ``1.0`` where ``|b| < DIV_EPS``.

    Returning 1.0 rather than 0.0 for the guarded case is the conventional choice and the better
    one: ``a / a`` is 1 in the limit, and a guard that returns 0 makes whole subtrees vanish,
    which the GA then learns to exploit as a cheap way to build constants.
    """
    b = np.asarray(b, dtype=np.float64) if not np.isscalar(b) else float(b)
    safe = np.where(np.abs(b) < DIV_EPS, 1.0, b)
    return np.where(np.abs(b) < DIV_EPS, 1.0, a / safe)


def k_neg(a):
    """``-a``."""
    return -a


def k_abs(a):
    """``|a|``."""
    return np.abs(a)


def plog(a):
    """Protected log: ``log1p(|a|)``.

    Defined and smooth everywhere, zero at zero, and monotone in ``|a|``. Plain ``log`` would
    need a guard *and* would still be discontinuous across it.
    """
    return np.log1p(np.abs(a))


def psqrt(a):
    """Protected square root: ``sqrt(|a|)``."""
    return np.sqrt(np.abs(a))


def square(a):
    """``a * a``.

    The one growth-rate primitive in the set. Composing it a few levels deep reaches large
    magnitudes fast, which is what the dispatcher's clip is for.
    """
    return a * a


def k_tanh(a):
    """``tanh(a)`` — a bounded squash into ``(-1, 1)``.

    Useful to the GA as a soft threshold, and the standard way an evolved expression expresses
    "saturate once this is big enough" without a discontinuity.
    """
    return np.tanh(a)


def expneg(a):
    """``exp(-|a|)`` — bounded in ``(0, 1]``, and cannot overflow.

    The set's only exponential. Plain ``exp`` is excluded because ``exp(800)`` is ``inf``, and a
    GP population *will* find its way to ``exp(exp(x))`` within a few generations.
    """
    return np.exp(-np.abs(a))


def k_min(a, b):
    """Elementwise minimum."""
    return np.minimum(a, b)


def k_max(a, b):
    """Elementwise maximum."""
    return np.maximum(a, b)


def if_gt(a, b, c, d):
    """``c`` where ``a > b``, else ``d``.

    This is how comparison enters an untyped (closure) GP: the whole function set consumes and
    returns floats, so a boolean type would break closure and require typed generation and typed
    crossover. Folding the test and both branches into one arity-4 float node gives the GA
    conditional behaviour with none of that machinery — and keeps the JSON form unchanged when
    strongly-typed GP arrives later.
    """
    return np.where(a > b, c, d)


# ---- fuzzy kernels ----------------------------------------------------------------------------
#
# The set above is arithmetic: it compares with ``if_gt``, which is a cliff. A feature one part in
# a thousand under the bar contributes exactly nothing, and one part over contributes everything.
# For a target defined by a *shape* — a click whose energy sits in a rough ratio across bands
# rather than at an exact one — that cliff throws away most of what distinguishes it, and the
# search spends its budget finding where to put the cliff instead of what the shape is.
#
# These are the graded versions. ``min`` and ``max`` are already the Godel t-norm and t-conorm and
# ``mul`` is the product t-norm, so the algebra needs only a complement, a second conorm, an
# implication, and the two membership kernels that turn a raw feature into a degree at all.
#
# Every one obeys the two rules above: total on the whole real line, and out-of-place.


def fnot(a):
    """Fuzzy complement: ``1 - a``.

    Meaningful when its argument is already a degree in [0, 1] — which is what ``fgauss`` and
    ``fsgt`` return. Left unclamped on purpose: clamping here would hide an expression that is
    feeding it something unbounded, and that is worth seeing in the tree rather than papering
    over.
    """
    return 1.0 - a


def probor(a, b):
    """Probabilistic t-conorm: ``a + b - a*b``.

    The soft ``or``. Where ``max`` takes whichever evidence is strongest and ignores the rest,
    this accumulates: two half-convinced members reach further than either alone, which is the
    behaviour wanted when a click shows weakly in several bands at once.
    """
    return a + b - a * b


def fgauss(a, b):
    """Graded ``a is near b``: ``exp(-(a - b)**2)``, in (0, 1].

    The membership kernel that matters for a shape target. ``if_gt(x, c, ...)`` asks whether a
    band ratio clears a bar; this asks how close it is to a value, and degrades smoothly either
    side. Cannot overflow — the exponent is never positive — and a difference large enough to
    square to ``inf`` gives ``exp(-inf) == 0``, which is the right answer rather than a hole.
    """
    d = a - b
    return np.exp(-(d * d))


def fsgt(a, b):
    """Graded ``a greater than b``: ``0.5 * (1 + tanh(a - b))``, in (0, 1).

    ``if_gt`` without the cliff. Near the crossing it is almost linear, so the search gets a
    gradient to follow rather than a step to guess the position of; far from it, it saturates and
    behaves as the hard comparison does.
    """
    return 0.5 * (1.0 + np.tanh(a - b))


def fimp(a, b):
    """Lukasiewicz implication: ``min(1, 1 - a + b)``.

    "If a then b", graded. This is how a rule reads in a tree: strong evidence for ``a`` without
    matching evidence for ``b`` pulls the value down, and anything else leaves it at 1.
    """
    return np.minimum(1.0, 1.0 - a + b)
