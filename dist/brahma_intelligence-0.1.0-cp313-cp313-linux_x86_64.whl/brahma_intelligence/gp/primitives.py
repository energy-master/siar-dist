# Vixen Intelligence c.2026
"""The numpy kernels behind the function set.

Two rules govern everything here, and both are load-bearing.

**Every kernel is total.** No domain holes. Division by zero, ``log`` of a negative, ``exp`` of
600 — each produces ``inf`` or ``nan``, and one ``nan`` anywhere in a score vector turns that
individual's fitness into ``nan``. Depending on how the comparison falls, such an individual then
either always or never wins a tournament, and either way the run is quietly broken while looking
completely normal. Rather than sanitise after the fact, the primitives are chosen so the hole
does not exist: ``pdiv`` guards its denominator, ``plog`` takes ``log1p(|x|)``, ``psqrt`` takes
``sqrt(|x|)``, and there is no unprotected ``exp`` or ``pow`` in the set at all.

**Every kernel is out-of-place.** A feature terminal returns a *view* into the dataset's feature
matrix. An in-place kernel would therefore write through that view and corrupt the features for
every individual evaluated afterwards — a bug that shows up as fitness drifting between
generations for no reason anyone can find. No ``out=`` arguments, no ``+=``.

Sanitisation (``nan_to_num`` plus a magnitude clip) happens once, in the evaluation dispatcher,
not in each kernel. One place means it cannot be forgotten when a primitive is added.

Kernels accept scalars or arrays interchangeably, because a constant subtree evaluates to a bare
float and numpy broadcasts it for free — materialising a full array per constant would be pure
waste at population scale.
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "expneg",
    "if_gt",
    "k_abs",
    "k_add",
    "k_max",
    "k_min",
    "k_mul",
    "k_neg",
    "k_sub",
    "k_tanh",
    "pdiv",
    "plog",
    "psqrt",
    "square",
]

#: Below this magnitude a denominator counts as zero. Not ``0.0``: a denominator of 1e-300 is
#: numerically zero for our purposes and dividing by it produces an overflow that the clip then
#: has to mop up, which loses the information anyway.
DIV_EPS = 1e-9


def k_add(a, b):
    """``a + b``."""
    return a + b


def k_sub(a, b):
    """``a - b``."""
    return a - b


def k_mul(a, b):
    """``a * b``."""
    return a * b


def pdiv(a, b):
    """Protected division: ``a / b``, or ``1.0`` where ``|b| < DIV_EPS``.

    Returning 1.0 rather than 0.0 for the guarded case is the conventional choice and the better
    one: ``a / a`` is 1 in the limit, and a guard that returns 0 makes whole subtrees vanish,
    which the GA then learns to exploit as a cheap way to build constants.
    """
    b = np.asarray(b, dtype=np.float64) if not np.isscalar(b) else float(b)
    safe = np.where(np.abs(b) < DIV_EPS, 1.0, b)
    return np.where(np.abs(b) < DIV_EPS, 1.0, a / safe)


def k_neg(a):
    """``-a``."""
    return -a


def k_abs(a):
    """``|a|``."""
    return np.abs(a)


def plog(a):
    """Protected log: ``log1p(|a|)``.

    Defined and smooth everywhere, zero at zero, and monotone in ``|a|``. Plain ``log`` would
    need a guard *and* would still be discontinuous across it.
    """
    return np.log1p(np.abs(a))


def psqrt(a):
    """Protected square root: ``sqrt(|a|)``."""
    return np.sqrt(np.abs(a))


def square(a):
    """``a * a``.

    The one growth-rate primitive in the set. Composing it a few levels deep reaches large
    magnitudes fast, which is what the dispatcher's clip is for.
    """
    return a * a


def k_tanh(a):
    """``tanh(a)`` — a bounded squash into ``(-1, 1)``.

    Useful to the GA as a soft threshold, and the standard way an evolved expression expresses
    "saturate once this is big enough" without a discontinuity.
    """
    return np.tanh(a)


def expneg(a):
    """``exp(-|a|)`` — bounded in ``(0, 1]``, and cannot overflow.

    The set's only exponential. Plain ``exp`` is excluded because ``exp(800)`` is ``inf``, and a
    GP population *will* find its way to ``exp(exp(x))`` within a few generations.
    """
    return np.exp(-np.abs(a))


def k_min(a, b):
    """Elementwise minimum."""
    return np.minimum(a, b)


def k_max(a, b):
    """Elementwise maximum."""
    return np.maximum(a, b)


def if_gt(a, b, c, d):
    """``c`` where ``a > b``, else ``d``.

    This is how comparison enters an untyped (closure) GP: the whole function set consumes and
    returns floats, so a boolean type would break closure and require typed generation and typed
    crossover. Folding the test and both branches into one arity-4 float node gives the GA
    conditional behaviour with none of that machinery — and keeps the JSON form unchanged when
    strongly-typed GP arrives later.
    """
    return np.where(a > b, c, d)
