# Vixen Intelligence c.2026
"""A tree bound to everything needed to *use* it.

A :class:`~brahma_intelligence.gp.tree.Node` is a shape. A :class:`Program` is that shape plus the
three things without which the shape means nothing:

* **feature_names** — the tree addresses features by integer index. The names are what make that
  index mean "the 2.4-2.6 kHz band energy" rather than "column 12 of whatever you happen to hand
  me". Checked on load, not assumed.
* **polarity** — whether the raw output already means "higher is more positive", or has to be
  negated first. A metric that separates the classes with *low* values is exactly as good a
  discovery, and this is what keeps the fitness, the threshold, the margin and the report all
  agreeing about which direction is which.
* **threshold** — where the decision is made. Calibrated on the *training* split. Calibrating on
  the split you then report is threshold leakage, and on a small corpus it flatters F1 by several
  points.

:meth:`Program.score` is the single place polarity is applied. Everything downstream — the
report, the threshold sweep, the database row — consumes its output, so none of them can disagree
about orientation. Every previous bug of this shape came from two code paths each deciding the
sign for themselves.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np

from ..errors import ProgramError
from .evaluate import evaluate_root
from .serialise import from_json, to_json
from .tree import Node, depth, feature_indices, render, size

__all__ = ["Program"]


@dataclass(frozen=True, slots=True)
class Program:
    """An evolved metric, ready to apply.

    Attributes:
        tree: The expression.
        feature_names: Names for every feature index the tree may read, in index order.
        polarity: ``+1`` to use the raw output, ``-1`` to negate it. See the module docstring.
        threshold: Decision threshold on the *oriented* score. ``nan`` until calibrated.
        objective: Which objective this program was evolved under. Recorded because a fitness
            number is meaningless without it.
        fitness: The training fitness. Kept for provenance; never reported as a result.
    """

    tree: Node
    feature_names: tuple[str, ...] = ()
    polarity: int = 1
    threshold: float = float("nan")
    objective: str = ""
    fitness: float = float("nan")

    # ---- properties the database promotes into columns -------------------------------------

    @property
    def n_nodes(self) -> int:
        """Node count — the bloat measure."""
        return size(self.tree)

    @property
    def depth(self) -> int:
        """Tree depth."""
        return depth(self.tree)

    @property
    def features_used(self) -> list[int]:
        """Distinct feature indices the tree reads, sorted.

        The *scientific* readout: "did the champion reference the band we planted the tone in?"
        is answerable from this without parsing the expression, and without depending on the tree
        having taken any particular one of the thousands of equivalent forms.
        """
        return feature_indices(self.tree)

    @property
    def infix(self) -> str:
        """The readable expression, with feature names substituted.

        Always print this next to a fitness number. A one-node champion — ``total_energy`` and
        nothing else — scores beautifully on any corpus where the classes differ in loudness, and
        reporting fitness alone makes that indistinguishable from a real discovery. See
        ``CLAUDE.md``.
        """
        return render(self.tree, list(self.feature_names) or None)

    # ---- using it --------------------------------------------------------------------------

    def raw(self, F: np.ndarray) -> np.ndarray:
        """The tree's unoriented output.

        Args:
            F: ``(n_features, n_windows)`` feature-major float64.

        Returns:
            ``(n_windows,)`` float64.

        Raises:
            ProgramError: If ``F`` has a different number of features than the program's name
                list. Silence here would mean scoring against whatever happened to be in that
                row.
        """
        if self.feature_names and F.shape[0] != len(self.feature_names):
            raise ProgramError(
                f"program expects {len(self.feature_names)} features, got {F.shape[0]}"
            )
        return evaluate_root(self.tree, F)

    def score(self, F: np.ndarray) -> np.ndarray:
        """The oriented score: higher always means "more like the target".

        The single place polarity is applied. Every consumer reads this, so no two of them can
        disagree about the sign.

        Args:
            F: ``(n_features, n_windows)`` feature-major float64.

        Returns:
            ``(n_windows,)`` float64.
        """
        v = self.raw(F)
        return v if self.polarity >= 0 else -v

    def predict(self, F: np.ndarray, threshold: float | None = None) -> np.ndarray:
        """Boolean decisions at a threshold.

        Args:
            F: ``(n_features, n_windows)`` feature-major float64.
            threshold: Overrides the program's own. Defaults to :attr:`threshold`.

        Returns:
            ``(n_windows,)`` bool, using ``score >= threshold`` — the same convention as
            :func:`brahma_intelligence.metrics.classification_report` and
            :func:`~brahma_intelligence.metrics.threshold_sweep`, so a reported "best threshold"
            reproduces exactly here.

        Raises:
            ProgramError: If no threshold is available. Guessing one would produce plausible
                predictions that mean nothing.
        """
        t = self.threshold if threshold is None else float(threshold)
        if t != t:
            raise ProgramError("program has no calibrated threshold; pass one explicitly")
        return self.score(F) >= t

    def with_calibration(self, *, threshold: float, polarity: int | None = None) -> "Program":
        """A copy with a new threshold (and optionally polarity).

        Args:
            threshold: The calibrated threshold, on the oriented score.
            polarity: New polarity, if it is being set at the same time.

        Returns:
            The new program. The original is unchanged — programs are frozen so that a
            calibration step cannot retroactively alter a program another result already refers
            to.
        """
        return Program(
            tree=self.tree,
            feature_names=self.feature_names,
            polarity=self.polarity if polarity is None else int(polarity),
            threshold=float(threshold),
            objective=self.objective,
            fitness=self.fitness,
        )

    # ---- serialisation ---------------------------------------------------------------------

    def to_dict(self) -> dict:
        """JSON-safe dict. The ``program`` field of a model document."""
        return {
            "tree": to_json(self.tree, list(self.feature_names) or None),
            "polarity": int(self.polarity),
            "threshold": float(self.threshold),
            "objective": self.objective,
            "fitness": float(self.fitness),
            # Re-derived on load, never trusted. Present so the file is readable.
            "infix": self.infix,
            "n_nodes": self.n_nodes,
            "depth": self.depth,
            "features_used": self.features_used,
        }

    @classmethod
    def from_dict(cls, d: dict, feature_names: Sequence[str]) -> "Program":
        """Rebuild from :meth:`to_dict` output.

        Args:
            d: The document.
            feature_names: The model's feature names. Feature indices are bounds-checked against
                this list, which is what turns a silently-shifted feature set into a refusal.

        Returns:
            The program.

        Raises:
            ProgramError: If the document is malformed or an index is out of range.
        """
        names = tuple(feature_names)
        tree = from_json(d.get("tree", d), n_features=len(names) or None)
        return cls(
            tree=tree,
            feature_names=names,
            polarity=int(d.get("polarity", 1)),
            threshold=float(d.get("threshold", float("nan"))),
            objective=str(d.get("objective", "")),
            fitness=float(d.get("fitness", float("nan"))),
        )

    def summary(self, width: int = 62) -> str:
        """A short printable block describing the program itself.

        Printed next to every report. The node count and the expression are the two numbers that
        tell you whether a strong score is a discovery or an artefact.

        Args:
            width: Total character width, matching the report block.

        Returns:
            A multi-line string, no trailing newline.
        """
        rule = "-" * width
        pad = 17
        used = self.features_used
        named = [self.feature_names[i] for i in used if i < len(self.feature_names)]
        lines = [
            rule,
            " CHAMPION METRIC",
            rule,
            f" {'objective':<{pad}}{self.objective}",
            f" {'fitness':<{pad}}{self.fitness:.4f}   (training; not a result — see the report)",
            f" {'polarity':<{pad}}{'+1 (higher = target)' if self.polarity >= 0 else '-1 (lower = target)'}",
            f" {'threshold':<{pad}}{self.threshold:.6g}",
            f" {'size':<{pad}}{self.n_nodes} nodes, depth {self.depth}",
            f" {'features used':<{pad}}{len(used)}",
        ]
        for name in named:
            lines.append(f" {'':<{pad}}{name}")
        lines += ["", " expression", f"   {self.infix}", rule]
        return "\n".join(lines)
