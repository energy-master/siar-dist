# Vixen Intelligence c.2026
"""Trees to JSON and back — safely.

brahma_lib's rule is absolute: *declarative JSON models — never pickle, never eval*. Honouring it
for genetic programming needs an argument, because a GP tree **is** a program, and "load a
program from a file and run it" is the shape of every remote-code-execution bug ever written.

Here is the argument, and it is the whole safety story:

    The only thing that crosses from the document into executable code is a **string used as a
    dictionary key** in :data:`~brahma_intelligence.gp.nodes.FUNCTIONS`.

There is no ``eval``, no ``exec``, no ``compile``, no ``pickle``, no ``getattr`` on a module, and
no import driven by file content. A hostile document can name an op that does not exist — and get
a :class:`~brahma_intelligence.errors.ProgramError` — or supply a wrong-arity argument list, or an
out-of-range feature index, and every one of those is rejected before evaluation. What it cannot
do is introduce a new operation, because the set of operations is fixed in source at import time.
``tests/test_no_eval.py`` greps the package for the dangerous constructs, because this is exactly
the kind of property that gets reintroduced by a well-meaning refactor.

The document carries a human-readable ``infix`` string and human-readable feature ``name``s.
Neither is trusted on load: the expression is **re-derived** from the reconstructed tree, and the
names are verified against the model's feature list. A cached string that has drifted from the
structure it claims to describe is worse than no string at all — it is a confident lie about what
a champion computes.
"""
from __future__ import annotations

import json
from typing import Any, Sequence

from ..errors import ProgramError
from .nodes import FUNCTIONS, arity_of
from .tree import Node, render, validate

__all__ = ["from_json", "loads", "to_json", "dumps"]


def to_json(node: Node, names: Sequence[str] | None = None) -> dict:
    """Serialise a tree to a JSON-safe dict.

    Args:
        node: The tree root.
        names: Feature names. When given, each feature terminal also carries its ``name``, which
            makes a saved model readable in a text editor and makes a feature-set mismatch
            diagnosable by eye. The ``index`` remains authoritative.

    Returns:
        A nested dict, structurally 1:1 with the tree.
    """
    if node.op == "const":
        return {"op": "const", "value": float(node.value or 0.0)}
    if node.op == "feature":
        i = int(node.index or 0)
        d: dict[str, Any] = {"op": "feature", "index": i}
        if names is not None and 0 <= i < len(names):
            d["name"] = names[i]
        return d
    return {"op": node.op, "args": [to_json(a, names) for a in node.args]}


def from_json(doc: Any, *, n_features: int | None = None) -> Node:
    """Rebuild a tree from a document, rejecting anything malformed.

    Args:
        doc: The dict produced by :func:`to_json`.
        n_features: If given, feature indices are bounds-checked against it. Always pass this
            when loading a model: an out-of-range index does not error during evaluation in any
            obvious way, it reads a *neighbouring feature* and produces a confident wrong number.

    Returns:
        The tree root.

    Raises:
        ProgramError: On a non-dict node, a missing or unknown ``op``, an arity mismatch, a
            terminal missing its payload, a non-finite constant, or an out-of-range feature
            index.
    """
    node = _walk(doc, n_features)
    validate(node)
    return node


def _walk(doc: Any, n_features: int | None) -> Node:
    if not isinstance(doc, dict):
        raise ProgramError(f"program node must be an object, got {type(doc).__name__}")
    op = doc.get("op")
    if not isinstance(op, str):
        raise ProgramError(f"program node needs a string 'op', got {op!r}")

    if op == "const":
        v = doc.get("value")
        if not isinstance(v, (int, float)) or isinstance(v, bool):
            raise ProgramError(f"const node needs a numeric 'value', got {v!r}")
        v = float(v)
        if v != v or v in (float("inf"), float("-inf")):
            raise ProgramError(f"const node value must be finite, got {v!r}")
        return Node(op="const", value=v)

    if op == "feature":
        i = doc.get("index")
        if not isinstance(i, int) or isinstance(i, bool) or i < 0:
            raise ProgramError(f"feature node needs a non-negative integer 'index', got {i!r}")
        if n_features is not None and i >= n_features:
            raise ProgramError(
                f"feature index {i} is out of range for {n_features} features — this program "
                f"was evolved against a different feature set"
            )
        return Node(op="feature", index=i)

    # The one and only data-to-code step: a string, used as a dict key, in a table fixed at
    # import time. An unknown key is an error, not a lookup that reaches further afield.
    if op not in FUNCTIONS:
        raise ProgramError(
            f"unknown op {op!r}; known: {', '.join(sorted(FUNCTIONS))}, feature, const"
        )
    args = doc.get("args", [])
    if not isinstance(args, list):
        raise ProgramError(f"op {op!r} needs a list of 'args', got {type(args).__name__}")
    want = arity_of(op)
    if len(args) != want:
        raise ProgramError(f"op {op!r} takes {want} arguments, got {len(args)}")
    return Node(op=op, args=tuple(_walk(a, n_features) for a in args))


def dumps(node: Node, names: Sequence[str] | None = None, *, indent: int | None = 2) -> str:
    """The tree as a JSON string.

    Args:
        node: The tree root.
        names: Feature names, for readability.
        indent: Passed to :func:`json.dumps`. ``2`` matches brahma_lib's ``j.dump(2)``.

    Returns:
        The JSON text.
    """
    return json.dumps(to_json(node, names), indent=indent, sort_keys=False)


def loads(text: str, *, n_features: int | None = None) -> Node:
    """Parse a JSON string into a tree.

    Args:
        text: JSON produced by :func:`dumps`.
        n_features: Bounds check for feature indices.

    Returns:
        The tree root.

    Raises:
        ProgramError: If the text is not valid JSON, or the document is malformed.
    """
    try:
        doc = json.loads(text)
    except json.JSONDecodeError as e:
        raise ProgramError(f"program is not valid JSON: {e}") from None
    return from_json(doc, n_features=n_features)


def infix(node: Node, names: Sequence[str] | None = None) -> str:
    """The readable expression, re-derived from the tree.

    A thin alias for :func:`brahma_intelligence.gp.tree.render`, named here so the "always
    re-derive, never trust the stored string" rule is visible at the serialisation boundary,
    which is the only place anyone would be tempted to break it.

    Args:
        node: The tree root.
        names: Feature names.

    Returns:
        The expression.
    """
    return render(node, list(names) if names is not None else None)
