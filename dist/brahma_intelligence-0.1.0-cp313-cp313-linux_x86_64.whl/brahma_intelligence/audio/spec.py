# Vixen Intelligence c.2026
"""The frontend specification — and why it travels with the model.

A :class:`FeatureSpec` fully determines how audio becomes numbers: sample rate, STFT geometry,
band layout, window length, normalisation. brahma_lib's rule is that this travels with the model
(``grid.hpp``, failure mode #4), because a detector addressed in Hz only resonates on the grid
geometry it evolved under, and inferring on a different STFT produces a confident meaningless
number rather than an error.

**Here the rule needs a second lock.** A brahma resonator is addressed in Hz and clip-fractions,
so the spec alone pins its meaning down. A GP tree is addressed by **feature index**, and feature
indices depend on the *extractor set* — which is not part of the STFT spec at all. Add one
extractor at the front of the list and every index above it shifts by one. The spec still matches
perfectly; the model now reads the wrong columns and reports a plausible number.

So compatibility is checked twice:

1. :meth:`FeatureSpec.compatible_with` — every STFT field, with a list of exactly what differs.
2. The model's ``feature_names`` against the live extractor registry — see
   :mod:`~brahma_intelligence.audio.features`.

And :attr:`feature_set` — the extractor set's version string — is folded into
:meth:`cache_key`, so a changed extractor cannot read stale ``.npy`` vectors off disk. Keying the
cache on the spec alone would make that failure silent *and* persistent.

Defaults match brahma_lib's ``FeatureSpec``: 16 kHz, 1024-point FFT, hop 256, 128 bands over
0-8 kHz, ``log1p``.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass

from ..errors import ConfigError, FeatureSpecMismatch

__all__ = ["FeatureSpec"]


@dataclass(frozen=True, slots=True)
class FeatureSpec:
    """How audio becomes a feature table.

    Attributes:
        sample_rate: Everything is resampled to this before analysis.
        n_fft: STFT window length in samples.
        hop: STFT hop in samples.
        fmin_hz: Lowest frequency included in the band layout.
        fmax_hz: Highest. ``0`` means Nyquist.
        n_bins: How many equal-width bands span ``[fmin_hz, fmax_hz]``.
        scale: ``"log1p"`` or ``"linear"``. ``log1p`` because band magnitudes span orders of
            magnitude and a linear scale makes every feature a proxy for total loudness.
        window_seconds: Length of one analysis window — one labelled sample.
        window_overlap: Fraction of overlap between consecutive windows, in ``[0, 1)``.
        rms_normalise: Scale each window to unit RMS before the STFT. **On by default, and this
            is the single most consequential default in the library.** If the target class is
            merely louder than the background, the GA discovers ``total_energy`` in generation 1,
            reaches AUC 1.000, and has learned nothing about the signature. Removing the level
            forces it to find *shape*. See ``CLAUDE.md``.
        feature_set: Version string of the extractor set. Part of the identity of a feature
            vector, and therefore part of the cache key.
    """

    sample_rate: int = 16_000
    n_fft: int = 1024
    hop: int = 256
    fmin_hz: float = 0.0
    fmax_hz: float = 8000.0
    n_bins: int = 128
    scale: str = "log1p"
    window_seconds: float = 4.0
    window_overlap: float = 0.5
    rms_normalise: bool = True
    feature_set: str = "brahma-features/1"

    def __post_init__(self) -> None:
        if self.n_fft < 8 or self.hop < 1 or self.n_bins < 1:
            raise ConfigError(f"invalid FeatureSpec geometry: {self}")
        if self.scale not in ("log1p", "linear"):
            raise ConfigError(f"unknown scale {self.scale!r}; use 'log1p' or 'linear'")
        if not 0 <= self.window_overlap < 1:
            raise ConfigError(f"window_overlap must be in [0, 1), got {self.window_overlap}")
        if self.window_seconds <= 0:
            raise ConfigError(f"window_seconds must be positive, got {self.window_seconds}")

    # ---- derived geometry ------------------------------------------------------------------

    @property
    def nyquist(self) -> float:
        """Half the sample rate."""
        return self.sample_rate / 2.0

    @property
    def f_high(self) -> float:
        """The effective upper band edge, resolving ``fmax_hz == 0`` to Nyquist."""
        return float(self.fmax_hz) if self.fmax_hz > 0 else self.nyquist

    @property
    def band_width_hz(self) -> float:
        """Width of one aggregation band."""
        return (self.f_high - max(0.0, self.fmin_hz)) / self.n_bins

    @property
    def window_samples(self) -> int:
        """Length of one analysis window in samples."""
        return int(round(self.window_seconds * self.sample_rate))

    @property
    def hop_samples(self) -> int:
        """Distance between consecutive analysis windows, in samples."""
        return max(1, int(round(self.window_samples * (1.0 - self.window_overlap))))

    def band_centres_hz(self) -> list[float]:
        """Centre frequency of every band, low to high.

        Matches ``frontend.cpp``: ``fmin + (b + 0.5) * band_width``. Frequency increases with
        band index, as in brahma_lib and SIAR, so a band index means the same thing across the
        three libraries.

        Returns:
            ``n_bins`` centre frequencies in Hz.
        """
        lo = max(0.0, float(self.fmin_hz))
        w = self.band_width_hz
        return [lo + (b + 0.5) * w for b in range(self.n_bins)]

    def band_of_hz(self, hz: float) -> int:
        """Which band contains a given frequency.

        Used by the self-test to ask "did the champion reference the band we planted the tone
        in?" without depending on the expression's exact form.

        Args:
            hz: A frequency.

        Returns:
            The band index, clamped into range.
        """
        lo = max(0.0, float(self.fmin_hz))
        b = int((float(hz) - lo) / self.band_width_hz)
        return max(0, min(self.n_bins - 1, b))

    # ---- validation ------------------------------------------------------------------------

    def validate(self) -> None:
        """Check the geometry can actually produce features.

        Raises:
            ConfigError: If a window is too short for the STFT to produce more than one frame.
                Every temporal feature would then be a constant column, every objective would go
                ``nan``, and the run would report a mystery rather than a mistake. Caught here,
                at configure time, rather than at generation 1.
        """
        if self.window_samples < 2 * self.n_fft:
            raise ConfigError(
                f"window_seconds={self.window_seconds} at {self.sample_rate} Hz gives "
                f"{self.window_samples} samples, which is fewer than 2*n_fft "
                f"({2 * self.n_fft}). Every temporal feature would be constant. Lengthen the "
                f"window or shorten n_fft."
            )
        if self.f_high <= max(0.0, self.fmin_hz):
            raise ConfigError(f"fmax_hz ({self.f_high}) must exceed fmin_hz ({self.fmin_hz})")
        if self.f_high > self.nyquist + 1e-6:
            raise ConfigError(
                f"fmax_hz ({self.f_high}) exceeds Nyquist ({self.nyquist}) for "
                f"sample_rate={self.sample_rate}"
            )

    def differences(self, other: "FeatureSpec") -> list[str]:
        """Which fields differ from another spec.

        Args:
            other: The spec to compare against.

        Returns:
            Human-readable ``"field: a != b"`` strings; empty if the specs match.
        """
        a, b = asdict(self), asdict(other)
        return [f"{k}: {a[k]!r} != {b[k]!r}" for k in sorted(a) if a[k] != b[k]]

    def compatible_with(self, other: "FeatureSpec") -> None:
        """Refuse if two specs are not the same.

        Args:
            other: The spec a saved model was evolved under.

        Raises:
            FeatureSpecMismatch: Listing every differing field. A partial match is not a partial
                problem — a model evolved at hop 256 and applied at hop 512 sees a different
                number of frames per window, so every temporal feature it reads means something
                else.
        """
        diffs = self.differences(other)
        if diffs:
            raise FeatureSpecMismatch(
                "this model was evolved under a different frontend:\n  " + "\n  ".join(diffs)
            )

    # ---- identity --------------------------------------------------------------------------

    def cache_key(self) -> str:
        """A short stable key identifying this spec *and* its feature set.

        Both halves are essential. The spec identifies the spectrogram; the feature set
        identifies which scalars were pulled out of it. A cache keyed on the spec alone hands
        back vectors of the wrong length — or worse, the right length and the wrong meaning —
        the first time an extractor is added.

        Returns:
            A 16-character hex digest.
        """
        payload = json.dumps(asdict(self), sort_keys=True).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()[:16]

    def to_dict(self) -> dict:
        """JSON-safe dict, for the model document."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "FeatureSpec":
        """Rebuild from :meth:`to_dict` output.

        Args:
            d: The document.

        Returns:
            The spec. Unknown keys are ignored so a model written by a later version still loads.
        """
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})

    def summary(self) -> str:
        """One line, for the console."""
        return (
            f"{self.sample_rate} Hz, n_fft={self.n_fft}, hop={self.hop}, "
            f"{self.n_bins} bands over {max(0.0, self.fmin_hz):.0f}-{self.f_high:.0f} Hz, "
            f"{self.scale}, {self.window_seconds:g}s windows @ {self.window_overlap:.0%} overlap"
            + (", RMS-normalised" if self.rms_normalise else ", RAW LEVEL (see CLAUDE.md)")
        )
