# Vixen Intelligence c.2026
"""The Fourier frontend: samples in, a frequency-by-time grid out.

This reproduces ``brahma_lib/src/frontend.cpp`` arithmetic for arithmetic, deliberately. The two
libraries analyse the same recordings for the same customer, and a band index or a frame time
that means something different in each is a trap that only surfaces when someone compares
results.

The contract, from ``grid.hpp``:

    A grid is ``(n_bins, n_frames)`` float32, **bin-major**, with band 0 the *lowest* frequency.
    ``bin_hz[b] = fmin + (b + 0.5) * band_width``. ``frame_s[t] = (t * hop + n_fft/2) / sr``.

The pipeline, in order:

1. Hann window, symmetric — ``0.5 * (1 - cos(2*pi*i / (n-1)))``. That is ``frontend.cpp``'s
   formula exactly. (Its periodic sibling, ``/n`` rather than ``/(n-1)``, is the better choice
   for perfect reconstruction, which is not what either library is doing.)
2. Real FFT per frame, magnitude.
3. Each rfft bin is assigned to exactly one of ``n_bins`` **equal-width** bands over
   ``[fmin, fmax]``; each band takes the *mean* magnitude of its members. Equal-width rather than
   mel because the targets are machine and vessel signatures — tonal, harmonic, and often
   concentrated well above where mel spends its resolution. Mel is a ``feature_set: 2`` question.
4. ``log1p``, because band magnitudes span orders of magnitude and on a linear scale every
   feature degenerates into a proxy for total loudness.

Vectorised over frames: one strided view of the signal, one batched ``rfft``, one
``np.add.reduceat``-style band aggregation via a precomputed index map. A per-frame Python loop
would dominate the cost of building a corpus.
"""
from __future__ import annotations

import numpy as np

from .spec import FeatureSpec

__all__ = ["band_map", "frame_times", "hann", "stft_grid"]


def hann(n: int) -> np.ndarray:
    """Symmetric Hann window of length ``n``.

    Args:
        n: Window length.

    Returns:
        ``(n,)`` float64. ``[1.0]`` for ``n == 1``, matching ``frontend.cpp``.
    """
    if n <= 1:
        return np.ones(max(1, n), dtype=np.float64)
    i = np.arange(n, dtype=np.float64)
    return 0.5 * (1.0 - np.cos(2.0 * np.pi * i / (n - 1)))


def band_map(spec: FeatureSpec) -> tuple[np.ndarray, np.ndarray]:
    """Which aggregation band each rfft bin belongs to.

    Mirrors ``frontend.cpp``'s ``band_of[k]``: a bin at frequency ``f`` is included when
    ``fmin <= f < fmax`` and lands in band ``int((f - fmin) / band_width)``.

    Args:
        spec: The frontend specification.

    Returns:
        ``(band_of, counts)``. ``band_of`` is ``(n_rfft,)`` int64 with ``-1`` for bins outside
        the range; ``counts`` is ``(n_bins,)`` float64 giving how many bins feed each band, used
        to take the mean. A band with zero members yields 0.0, exactly as the C++ does — that
        happens when ``n_bins`` exceeds the FFT's resolution, and producing a constant column is
        a better failure than a divide by zero.
    """
    n_rfft = spec.n_fft // 2 + 1
    bin_hz_step = spec.sample_rate / spec.n_fft
    lo = max(0.0, float(spec.fmin_hz))
    hi = spec.f_high
    width = (hi - lo) / spec.n_bins

    f = np.arange(n_rfft, dtype=np.float64) * bin_hz_step
    band = np.full(n_rfft, -1, dtype=np.int64)
    inside = (f >= lo) & (f < hi)
    band[inside] = np.clip(((f[inside] - lo) / width).astype(np.int64), 0, spec.n_bins - 1)

    counts = np.zeros(spec.n_bins, dtype=np.float64)
    if inside.any():
        np.add.at(counts, band[inside], 1.0)
    return band, counts


def frame_times(n_frames: int, spec: FeatureSpec) -> np.ndarray:
    """Centre time of each STFT frame, in seconds.

    Args:
        n_frames: How many frames.
        spec: The frontend specification.

    Returns:
        ``(n_frames,)`` float64, matching ``frontend.cpp``'s ``frame_s``.
    """
    t = np.arange(n_frames, dtype=np.float64)
    return (t * spec.hop + spec.n_fft / 2.0) / spec.sample_rate


def stft_grid(samples: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    """Turn one window of samples into a frequency-by-time grid.

    Args:
        samples: ``(n,)`` mono samples already at ``spec.sample_rate``.
        spec: The frontend specification.

    Returns:
        ``(n_bins, n_frames)`` float32, bin-major, band 0 lowest. At least one frame is always
        produced — a short clip is zero-padded rather than yielding an empty grid, matching
        ``frontend.cpp``.
    """
    x = np.asarray(samples, dtype=np.float64).ravel()
    n_fft, hop = spec.n_fft, spec.hop

    n_frames = (x.size - n_fft) // hop + 1 if x.size >= n_fft else 0
    if n_frames < 1:
        n_frames = 1
        x = np.pad(x, (0, max(0, n_fft - x.size)))

    # One strided view over the signal — no per-frame copy, no Python loop.
    frames = np.lib.stride_tricks.as_strided(
        x,
        shape=(n_frames, n_fft),
        strides=(x.strides[0] * hop, x.strides[0]),
        writeable=False,
    )
    spectra = np.abs(np.fft.rfft(frames * hann(n_fft), axis=1))  # (n_frames, n_rfft)

    band, counts = band_map(spec)
    grid = np.zeros((spec.n_bins, n_frames), dtype=np.float64)
    inside = band >= 0
    if inside.any():
        # Sum each frame's magnitudes into their bands, then divide by the member count to get
        # the mean — the same two-step the C++ does, and the reason a wide band is not simply
        # louder than a narrow one.
        np.add.at(grid, band[inside], spectra[:, inside].T)
        nz = counts > 0
        grid[nz] /= counts[nz, None]

    if spec.scale == "log1p":
        grid = np.log1p(grid)
    return np.ascontiguousarray(grid, dtype=np.float32)
