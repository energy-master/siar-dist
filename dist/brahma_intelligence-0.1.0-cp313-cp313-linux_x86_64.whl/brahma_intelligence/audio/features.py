# Vixen Intelligence c.2026
"""Turning a spectrogram into a fixed-length vector of scalars.

This is the vocabulary the GP search actually has. A metric the feature set cannot express is a
metric the GA cannot find, however long it runs — so what goes in here matters more than any
parameter in ``GAConfig``.

**The organising principle is scale invariance.** brahma_lib's failure mode #1 is that a detector
which is not energy-normalised saturates on loud clips and the GA loses its gradient. The GP
version of that failure is worse, because it does not look like a failure: if the target class is
even slightly louder than the background, the champion is the one-node tree ``band_energy_mean``,
it reaches AUC 1.000 in generation 1, and it has learned the recording level rather than the
signature. It will then fail on the first tape recorded at a different gain.

Two defences, both here:

* Windows are RMS-normalised before the STFT (:attr:`FeatureSpec.rms_normalise`), so absolute
  level is gone before features are computed at all.
* **Ratio and shape features are first-class, not an afterthought.** Band *ratios*, spectral
  centroid and spread, flatness, entropy, contrast, slope — every one of these is invariant to a
  gain change by construction. They are the majority of the set, not a supplement to it.

The set is versioned (``FeatureSpec.feature_set``) because feature *indices* are what a saved
program addresses. Adding one extractor at the front shifts every index above it, and the model
would keep loading and start reading the wrong columns. The version string plus the name list are
what turn that into a refusal — see :mod:`~brahma_intelligence.audio.spec`.

Every extractor returns a fixed number of scalars whatever the input, so the vector length is a
property of the *spec*, not of the audio.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from ..ga.registry import Registry
from .spec import FeatureSpec

__all__ = ["EXTRACTORS", "FEATURE_SET_VERSION", "extract", "feature_names"]

#: Bump this whenever the extractor set changes in any way that moves an index. It is part of the
#: cache key and part of the model's compatibility check.
FEATURE_SET_VERSION = "brahma-features/1"

#: Octave-ish band groups, as fractions of the analysed range. Fractions rather than absolute Hz
#: so the same grouping works whatever ``fmin``/``fmax`` the spec uses.
OCTAVE_EDGES = (0.0, 0.0625, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 1.0)

#: Guards a division whose denominator is a sum of non-negative magnitudes.
EPS = 1e-12


@dataclass(frozen=True, slots=True)
class Extractor:
    """One named group of features.

    Attributes:
        name: Registry name.
        doc: One line — what it measures and why it is here. Shown by ``bx features``.
        names: Given a spec, the feature names this extractor produces, in order.
        compute: Given a grid and a spec, the matching values.
    """

    name: str
    doc: str
    names: Callable[[FeatureSpec], list[str]]
    compute: Callable[[np.ndarray, FeatureSpec], np.ndarray]


EXTRACTORS: Registry = Registry("feature extractor")


def _register(name: str, doc: str, names_fn, compute_fn) -> None:
    EXTRACTORS.add(name, Extractor(name, doc, names_fn, compute_fn), doc=doc)


def _octave_slices(spec: FeatureSpec) -> list[tuple[int, int, str]]:
    """Band index ranges for each octave-ish group, with a Hz-labelled name."""
    lo, hi = max(0.0, spec.fmin_hz), spec.f_high
    out: list[tuple[int, int, str]] = []
    for a, b in zip(OCTAVE_EDGES[:-1], OCTAVE_EDGES[1:]):
        i0 = int(a * spec.n_bins)
        i1 = max(i0 + 1, int(b * spec.n_bins))
        f0 = lo + a * (hi - lo)
        f1 = lo + b * (hi - lo)
        out.append((i0, min(i1, spec.n_bins), f"{f0:.0f}_{f1:.0f}hz"))
    return out


# --------------------------------------------------------------------------------------------
# Band energies and ratios
# --------------------------------------------------------------------------------------------

def _band_names(spec: FeatureSpec) -> list[str]:
    return [f"band_{tag}" for _, _, tag in _octave_slices(spec)]


def _band_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    return np.array(
        [float(grid[i0:i1].mean()) for i0, i1, _ in _octave_slices(spec)], dtype=np.float64
    )


_register(
    "band_energy",
    "Mean log-magnitude in each octave-ish band. The 'where is the energy' primitives.",
    _band_names,
    _band_values,
)


def _ratio_names(spec: FeatureSpec) -> list[str]:
    tags = [t for _, _, t in _octave_slices(spec)]
    out = [f"ratio_{tags[i]}_over_total" for i in range(len(tags))]
    out += [f"ratio_{tags[i]}_over_{tags[i + 1]}" for i in range(len(tags) - 1)]
    return out


def _ratio_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    b = _band_values(grid, spec)
    total = float(b.sum()) + EPS
    out = list(b / total)
    out += [float(b[i] / (b[i + 1] + EPS)) for i in range(len(b) - 1)]
    return np.array(out, dtype=np.float64)


_register(
    "band_ratio",
    "Each band's share of the total, and adjacent-band ratios. Invariant to gain by "
    "construction — the antidote to a champion that has only learned recording level.",
    _ratio_names,
    _ratio_values,
)


# --------------------------------------------------------------------------------------------
# Spectral shape
# --------------------------------------------------------------------------------------------

def _shape_names(spec: FeatureSpec) -> list[str]:
    return [
        "spectral_centroid_hz",
        "spectral_spread_hz",
        "spectral_skew",
        "spectral_kurtosis",
        "spectral_rolloff85_hz",
        "spectral_rolloff95_hz",
        "spectral_flatness",
        "spectral_entropy",
        "spectral_slope",
        "spectral_crest",
    ]


def _shape_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    p = grid.mean(axis=1).astype(np.float64)          # mean spectrum over time
    hz = np.asarray(spec.band_centres_hz(), dtype=np.float64)
    w = p / (p.sum() + EPS)

    centroid = float((w * hz).sum())
    spread = float(np.sqrt(((hz - centroid) ** 2 * w).sum()))
    if spread > EPS:
        skew = float((((hz - centroid) / spread) ** 3 * w).sum())
        kurt = float((((hz - centroid) / spread) ** 4 * w).sum())
    else:
        skew = kurt = 0.0

    cum = np.cumsum(w)
    roll85 = float(hz[int(np.searchsorted(cum, 0.85))]) if cum[-1] > 0 else 0.0
    roll95 = float(hz[int(np.searchsorted(cum, 0.95))]) if cum[-1] > 0 else 0.0

    pos = np.maximum(p, EPS)
    flatness = float(np.exp(np.log(pos).mean()) / (pos.mean() + EPS))
    entropy = float(-(w * np.log(np.maximum(w, EPS))).sum() / np.log(max(2, w.size)))

    # Least-squares tilt of the spectrum against frequency. A tonal source has a different tilt
    # from a broadband one, independent of how loud either is.
    hzc = hz - hz.mean()
    slope = float((hzc * (p - p.mean())).sum() / ((hzc**2).sum() + EPS))
    crest = float(p.max() / (p.mean() + EPS))

    return np.array(
        [centroid, spread, skew, kurt, roll85, roll95, flatness, entropy, slope, crest],
        dtype=np.float64,
    )


_register(
    "spectral_shape",
    "Centroid, spread, skew, kurtosis, rolloff, flatness, entropy, slope, crest of the "
    "time-averaged spectrum. Describes the shape, not the level.",
    _shape_names,
    _shape_values,
)


def _contrast_names(spec: FeatureSpec) -> list[str]:
    return [f"contrast_{tag}" for _, _, tag in _octave_slices(spec)]


def _contrast_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    p = grid.mean(axis=1).astype(np.float64)
    out = []
    for i0, i1, _ in _octave_slices(spec):
        seg = p[i0:i1]
        if seg.size < 2:
            out.append(0.0)
            continue
        # Peak-minus-valley within the band, using quantiles rather than min/max so one noisy
        # bin cannot define the whole feature.
        out.append(float(np.quantile(seg, 0.95) - np.quantile(seg, 0.05)))
    return np.array(out, dtype=np.float64)


_register(
    "spectral_contrast",
    "Peak-minus-valley within each band. High for tonal or harmonic content, low for noise — "
    "the most direct 'is there a tone here' feature in the set.",
    _contrast_names,
    _contrast_values,
)


# --------------------------------------------------------------------------------------------
# Temporal structure
# --------------------------------------------------------------------------------------------

def _temporal_names(spec: FeatureSpec) -> list[str]:
    return [
        "frame_energy_mean",
        "frame_energy_std",
        "frame_energy_max",
        "frame_energy_min",
        "frame_energy_cv",
        "flux_mean",
        "flux_std",
        "flux_max",
    ]


def _temporal_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    e = grid.mean(axis=0).astype(np.float64)          # energy per frame
    mean = float(e.mean())
    std = float(e.std())
    cv = float(std / (abs(mean) + EPS))               # scale-free steadiness

    if grid.shape[1] > 1:
        d = np.diff(grid.astype(np.float64), axis=1)
        flux = np.sqrt((d**2).sum(axis=0))
        fm, fs, fx = float(flux.mean()), float(flux.std()), float(flux.max())
    else:
        fm = fs = fx = 0.0

    return np.array(
        [mean, std, float(e.max()), float(e.min()), cv, fm, fs, fx], dtype=np.float64
    )


_register(
    "temporal",
    "Frame-energy statistics and spectral flux. Separates a steady hum from a transient: a "
    "sustained tone has low flux and low energy variation, an impact has neither.",
    _temporal_names,
    _temporal_values,
)


def _bandvar_names(spec: FeatureSpec) -> list[str]:
    return [f"bandvar_{tag}" for _, _, tag in _octave_slices(spec)]


def _bandvar_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    g = grid.astype(np.float64)
    return np.array(
        [float(g[i0:i1].mean(axis=0).std()) for i0, i1, _ in _octave_slices(spec)],
        dtype=np.float64,
    )


_register(
    "band_variance",
    "How much each band's energy fluctuates over the window. A steady tone is quiet here; an "
    "intermittent source is not.",
    _bandvar_names,
    _bandvar_values,
)


def _peak_names(spec: FeatureSpec) -> list[str]:
    return ["peak_band_hz", "peak_band_prominence", "peak_band_share", "n_strong_bands"]


def _peak_values(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    p = grid.mean(axis=1).astype(np.float64)
    hz = np.asarray(spec.band_centres_hz(), dtype=np.float64)
    k = int(np.argmax(p))
    med = float(np.median(p))
    total = float(p.sum()) + EPS
    strong = float(np.count_nonzero(p > med + 2.0 * (np.std(p) + EPS)))
    return np.array(
        [float(hz[k]), float(p[k] - med), float(p[k] / total), strong], dtype=np.float64
    )


_register(
    "spectral_peak",
    "Where the loudest band is, how far it stands above the median, and how many bands are "
    "strong. Lets an expression name a frequency without hard-coding an index.",
    _peak_names,
    _peak_values,
)


# --------------------------------------------------------------------------------------------
# The public surface
# --------------------------------------------------------------------------------------------

def feature_names(spec: FeatureSpec) -> list[str]:
    """Every feature name, in vector order.

    Extractors are visited in **sorted registry order**, so the vector layout is a pure function
    of the spec and cannot depend on import order. That is what makes an index stable enough to
    save in a model.

    Args:
        spec: The frontend specification.

    Returns:
        Feature names.
    """
    out: list[str] = []
    for name in EXTRACTORS.names():
        out.extend(EXTRACTORS.get(name).names(spec))
    return out


def extract(grid: np.ndarray, spec: FeatureSpec) -> np.ndarray:
    """Reduce one grid to its feature vector.

    Args:
        grid: ``(n_bins, n_frames)`` from :func:`~brahma_intelligence.audio.stft.stft_grid`.
        spec: The frontend specification.

    Returns:
        ``(n_features,)`` float64, aligned with :func:`feature_names`. Non-finite values are
        replaced with 0.0 here rather than left to poison a fitness later — a feature that came
        out ``nan`` on one window would make that individual's objective undefined and take a
        whole individual out of the run for a reason that has nothing to do with the individual.
    """
    parts = [EXTRACTORS.get(n).compute(grid, spec) for n in EXTRACTORS.names()]
    v = np.concatenate(parts) if parts else np.zeros(0, dtype=np.float64)
    return np.nan_to_num(v, nan=0.0, posinf=0.0, neginf=0.0)


def describe_features(spec: FeatureSpec | None = None) -> list[tuple[str, int, str]]:
    """``(extractor, count, doc)`` per extractor — what ``bx features`` prints.

    Args:
        spec: A spec, so the counts are real. Defaults to the library default.

    Returns:
        One row per extractor, sorted by name.
    """
    s = spec or FeatureSpec()
    return [
        (n, len(EXTRACTORS.get(n).names(s)), EXTRACTORS.doc(n)) for n in EXTRACTORS.names()
    ]
