# Vixen Intelligence c.2026
"""The exception hierarchy.

Every failure this library raises deliberately is a :class:`BrahmaError`, so a caller embedding
it can catch one type and know the difference between "brahma refused" and "numpy crashed".

The distinctions that matter are between failures that mean *different things to fix*:

* :class:`ConfigError` — you asked for something incoherent. Raised at configure time, before
  any audio is read or any generation runs. Discovering at generation 7 that your selector needs
  per-case fitness and your objective cannot supply it wastes minutes for no reason.
* :class:`CorpusError` — the audio on disk cannot support the experiment (one class, one
  recording per class, no readable files).
* :class:`FeatureSpecMismatch` / :class:`FeatureSetMismatch` — a saved model met a frontend it
  did not evolve under. Both are refusals, not warnings: a GP tree is addressed by feature
  *index*, so a shifted index does not error, it silently scores the wrong number.
* :class:`SchemaMismatch` — a JSON document from a different (or future) version of the format.
* :class:`ProgramError` — a tree document that cannot be reconstructed safely.
"""
from __future__ import annotations

__all__ = [
    "BrahmaError",
    "ConfigError",
    "CorpusError",
    "FeatureSetMismatch",
    "FeatureSpecMismatch",
    "ProgramError",
    "SchemaMismatch",
    "StoreError",
]


class BrahmaError(Exception):
    """Base class for every error this library raises deliberately."""


class ConfigError(BrahmaError):
    """A configuration that cannot work, caught before the run starts."""


class CorpusError(BrahmaError):
    """The corpus on disk cannot support the requested experiment."""


class SchemaMismatch(BrahmaError):
    """A JSON document whose ``schema`` field is not one this code understands."""


class FeatureSpecMismatch(BrahmaError):
    """A model was asked to score audio processed with a different frontend."""


class FeatureSetMismatch(BrahmaError):
    """A model's feature names do not match the current extractor registry.

    Distinct from :class:`FeatureSpecMismatch` because the fix is different: the STFT is fine,
    but the feature vector has been re-ordered or re-sized underneath the saved indices.
    """


class ProgramError(BrahmaError):
    """A program document that cannot be reconstructed into a valid tree."""


class StoreError(BrahmaError):
    """The results database refused an operation."""
