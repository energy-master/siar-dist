# Vixen Intelligence c.2026
"""The one registry type, used for every pluggable thing.

Selection strategies, variation operators, objectives and feature extractors are all "a named
implementation you can swap from config". Writing four bespoke lookup mechanisms for that is four
places for a name to be accepted by the config parser and then not found at run time.

Two properties are load-bearing:

* **The documentation lives next to the implementation.** ``register`` demands a ``doc``, and
  :meth:`Registry.describe` is what ``bx objectives`` / ``bx selections`` / ``bx features``
  print. A listing built from the registry cannot drift from what actually exists, which a
  hand-maintained table in the README always eventually does.
* **Iteration is sorted, never set order.** Anything that iterates a registry while consuming
  randomness would otherwise vary with insertion order and, for sets, with ``PYTHONHASHSEED``.
  That is the classic way a seeded GA stops reproducing between processes.

Unknown names fail loudly and *helpfully* — the error lists what does exist, because the usual
cause is a typo or a strategy that has not been ported yet.
"""
from __future__ import annotations

from typing import Callable, Generic, Iterator, TypeVar

from ..errors import ConfigError

__all__ = ["Registry"]

T = TypeVar("T")


class Registry(Generic[T]):
    """A name → implementation map with attached one-line documentation.

    Args:
        kind: What this registry holds, e.g. ``"selection strategy"``. Used in error messages,
            so it should read naturally in "unknown selection strategy 'foo'".
    """

    def __init__(self, kind: str) -> None:
        self.kind = kind
        self._items: dict[str, T] = {}
        self._docs: dict[str, str] = {}

    def register(self, name: str, *, doc: str) -> Callable[[T], T]:
        """Decorator registering an implementation under ``name``.

        Args:
            name: The config-facing name. Lower snake case by convention.
            doc: One line, shown by ``describe()`` and therefore by the CLI. Say what it does and
                when to reach for it, not how it is implemented.

        Returns:
            The decorator, which returns its argument unchanged so the function stays directly
            importable and testable.

        Raises:
            ConfigError: If ``name`` is already taken. Silent replacement would mean the
                behaviour depends on import order.
        """
        if name in self._items:
            raise ConfigError(f"{self.kind} {name!r} is already registered")

        def wrap(obj: T) -> T:
            self._items[name] = obj
            self._docs[name] = doc
            return obj

        return wrap

    def add(self, name: str, obj: T, *, doc: str) -> T:
        """Register an already-constructed object (a partial, a class instance).

        Args:
            name: The config-facing name.
            obj: The implementation.
            doc: One line of documentation.

        Returns:
            ``obj``.
        """
        return self.register(name, doc=doc)(obj)

    def get(self, name: str) -> T:
        """Look up an implementation.

        Args:
            name: The registered name.

        Returns:
            The implementation.

        Raises:
            ConfigError: If ``name`` is not registered. The message lists every known name.
        """
        try:
            return self._items[name]
        except KeyError:
            known = ", ".join(self.names()) or "(none registered)"
            raise ConfigError(f"unknown {self.kind} {name!r}; known: {known}") from None

    def doc(self, name: str) -> str:
        """The one-line documentation for ``name``."""
        self.get(name)
        return self._docs[name]

    def names(self) -> list[str]:
        """Every registered name, **sorted** — never set order, so iteration is deterministic."""
        return sorted(self._items)

    def describe(self) -> list[tuple[str, str]]:
        """``(name, doc)`` pairs, sorted by name. The CLI listing, straight from the source."""
        return [(n, self._docs[n]) for n in self.names()]

    def __contains__(self, name: object) -> bool:
        return name in self._items

    def __iter__(self) -> Iterator[str]:
        return iter(self.names())

    def __len__(self) -> int:
        return len(self._items)

    def __repr__(self) -> str:
        return f"Registry({self.kind!r}, {len(self)} entries)"
