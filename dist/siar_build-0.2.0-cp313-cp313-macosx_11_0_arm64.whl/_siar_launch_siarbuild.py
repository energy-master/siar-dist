# Vixen Intelligence c.2026
"""Console-script launcher for `siar-build`: check that this build can load, then get out of the way.

Written into this wheel by siar-dist/tools/build_release.py. Everything after the guard belongs to
the program: its arguments, its exit status, its streams. Nothing here is re-implemented.
"""
from __future__ import annotations

import sys

#: What this wheel's compiled extension needs, read out of it when the wheel was built.
GLIBC_FLOOR = None

#: The command a client typed, for the message.
COMMAND = "siar-build"


def _installed_glibc() -> str:
    """This machine's glibc version as text, or "" if it has none or will not say."""
    try:
        import os
        import re

        answer = os.confstr("CS_GNU_LIBC_VERSION") or ""
        found = re.search(r"\d+\.\d+", answer)
        return found.group(0) if found else ""
    except Exception:
        return ""


def _short(exc: BaseException) -> str:
    """The message when the `siar` package is not installed to render the full one."""
    have = _installed_glibc()
    need = ".".join(str(n) for n in GLIBC_FLOOR) if GLIBC_FLOOR else "a newer version"
    return "\n".join([
        "error: " + COMMAND + " cannot start -- the C library on this machine is too old for it.",
        "",
        "  this machine has  glibc " + (have or "unknown"),
        "  this build needs  glibc " + need + " or newer",
        "",
        "  glibc is the core of a Linux distribution and is not upgraded on its own. Run this on",
        "  a newer distribution or in a container, or ask Vixen Intelligence for a build against",
        "  an older glibc -- nothing in the program needs a recent one.",
        "",
        "The original error follows.",
        "",
        "  " + str(exc),
    ])


def _explain(exc: BaseException) -> str:
    """The full account where `siar` is installed, the short one otherwise."""
    try:
        from siar.glibc import explain, is_glibc_error
    except ImportError:
        return _short(exc)
    return explain(exc, COMMAND) if is_glibc_error(exc) else _short(exc)


def main() -> int:
    """Load the program and run it, or say why it cannot be loaded."""
    try:
        from siarbuild.cli import main as _run
    except ImportError as exc:
        text = str(exc)
        if "GLIBC_" not in text or "not found" not in text:
            raise
        sys.stderr.write(_explain(exc) + "\n")
        return 1
    return _run()
