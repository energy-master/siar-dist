# Vixen Intelligence c.2026
"""The parts of a generated scanner that are the same whichever kind it is.

siar-build now writes two kinds of algorithm — one evolved metric with a threshold, and a society
of twenty of them taking a vote — and almost everything between siar-app's frame grid and the
boxes that come out is common to both: refusing a grid the model cannot read, turning a window's
rows into the 61-feature vector brahma evolved against, merging runs of firing windows into boxes,
and describing the spectrogram under one.

That is about a hundred and twenty lines, and two copies of it would be two answers to *what does
this model measure* which agree on the day they are written. It lives here, in the package, for the
same reason :mod:`siarbuild.rms` does: the code the parity gate measures and the code the shipped
model runs must be one source file rather than two that match. It is copied into every generated
package by :func:`siarbuild.vendor.copy_runtime`, hashed into ``VENDOR.json`` and checked in both
directions by :func:`siarbuild.parity.check_vendor`.

**It imports numpy and nothing else**, exactly as :mod:`siarbuild.rms` does, and the three
frontend functions it needs — ``extract``, ``feature_names`` and ``band_map`` — are handed in by
the caller rather than imported here.

That is not indirection for its own sake. This one file has to work in two homes: inside a
generated package, where brahma lives under ``._brahma`` and is reached by a relative import, and
in the siar-build source tree, where it lives under its own top-level name. Writing that as a
``try/except ImportError`` would put an *absolute* brahma import into a shipped package — which
works on the build machine and fails on a survey box that has siar-app and nothing else, and which
is the precise failure vendoring exists to prevent. ``tests/test_pipeline.py`` greps every
generated file for one. So the import stays with the caller, who knows which home it is in.
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "SPEC_FIELDS",
    "WindowFeatures",
    "band_extent",
    "merge_runs",
    "peak_stats",
    "require_compatible",
]

#: ``FeatureSpec`` fields a model document carries. Filtered rather than splatted, so a document
#: written by a newer brahma with an extra field loads instead of raising ``TypeError``.
SPEC_FIELDS = (
    "sample_rate", "n_fft", "hop", "fmin_hz", "fmax_hz", "n_bins",
    "scale", "window_seconds", "window_overlap", "rms_normalise", "feature_set",
)


def require_compatible(spec, names: tuple[str, ...], grid, feature_names) -> None:
    """Refuse a grid this model cannot read.

    Each of these produces a wrong number rather than an exception if it is let through, and the
    wrong number looks exactly like a right one.

    Args:
        spec: The model's ``FeatureSpec``.
        names: The feature names it was evolved against.
        grid: siar-app's ``FrameGrid``.
        feature_names: brahma's ``feature_names``, from whichever home the caller is in.

    Raises:
        RuntimeError: On a different STFT geometry, or a feature set that has shifted.
    """
    problems = []
    if int(grid.fft) != spec.n_fft:
        problems.append(f"fft {grid.fft} != {spec.n_fft}")
    if int(grid.hop) != spec.hop:
        problems.append(f"hop {grid.hop} != {spec.hop}")
    if int(round(grid.sample_rate)) != spec.sample_rate:
        problems.append(f"sample rate {grid.sample_rate:g} != {spec.sample_rate}")
    if problems:
        raise RuntimeError(
            "this model was evolved under a different frontend: "
            + "; ".join(problems)
            + f". Re-run with --fft {spec.n_fft} --hop {spec.hop}, on audio recorded at "
            f"{spec.sample_rate} Hz. A model reads its features by index off a grid of a fixed "
            f"geometry; a different one is a different measurement."
        )
    current = tuple(feature_names(spec))
    if current != names:
        first = next(
            (f"index {i}: {a!r} != {b!r}"
             for i, (a, b) in enumerate(zip(names, current)) if a != b),
            f"lengths differ: {len(names)} vs {len(current)}",
        )
        raise RuntimeError(
            f"the vendored feature set does not match the one this model was evolved against "
            f"({first}). Feature indices have shifted, so the saved program would read the wrong "
            f"columns."
        )


class WindowFeatures:
    """Analysis windows of a siar-app frame grid, as brahma feature vectors.

    The expensive half of scoring, and the half that does not depend on which program is asking —
    which is what lets a society of twenty run for about one percent more than one model.

    Args:
        spec: The model's ``FeatureSpec``.
        normaliser: A :class:`siarbuild.rms.WindowNormaliser`, or ``None`` when the model was
            evolved with ``rms_normalise=False``.
        extract: brahma's ``extract``, from whichever home the caller is in.
        band_map: brahma's ``band_map``, likewise.
    """

    __slots__ = ("_spec", "_norm", "_extract", "_band", "_inside", "_counts", "_nz",
                 "_width", "frames", "stride")

    def __init__(self, spec, normaliser, extract, band_map) -> None:
        self._spec = spec
        self._norm = normaliser
        self._extract = extract
        self._band, self._counts = band_map(spec)
        self._inside = self._band >= 0
        self._nz = self._counts > 0
        w = spec.window_samples
        self.frames = (w - spec.n_fft) // spec.hop + 1
        self.stride = spec.hop_samples // spec.hop
        self._width = 0

    def n_windows(self, mags: np.ndarray) -> int:
        """How many analysis windows a grid holds. Zero for a recording shorter than one."""
        if mags.shape[0] < self.frames:
            return 0
        return (mags.shape[0] - self.frames) // self.stride + 1

    def one(self, mags: np.ndarray, first: int) -> np.ndarray:
        """One window's feature vector.

        Takes the whole grid rather than the window's rows because the RMS reconstruction needs a
        few frames of context either side to see the window's edges — see :mod:`siarbuild.rms`.
        The features themselves are computed from the window's own rows and nothing else.
        """
        scale = self._norm.scale(mags, first) if self._norm is not None else 1.0
        block = mags[first: first + self.frames]

        g = np.zeros((self._spec.n_bins, block.shape[0]), dtype=np.float64)
        np.add.at(g, self._band[self._inside], block[:, self._inside].T.astype(np.float64) * scale)
        g[self._nz] /= self._counts[self._nz, None]
        if self._spec.scale == "log1p":
            g = np.log1p(g)
        out = self._extract(np.ascontiguousarray(g, dtype=np.float32), self._spec)
        self._width = out.shape[0]
        return out

    def all(self, mags: np.ndarray) -> np.ndarray:
        """Every window's feature vector, as ``(n_windows, n_features)``.

        One pass, for the caller that is about to evaluate more than one program. A one-hour
        recording at a two-second hop is under a megabyte, so building the whole table costs
        nothing and turns twenty per-window tree walks into twenty vectorised calls.
        """
        n = self.n_windows(mags)
        if n < 1:
            return np.zeros((0, self._width), dtype=np.float64)
        return np.stack([self.one(mags, w * self.stride) for w in range(n)])


def merge_runs(firing, *, min_windows: int, gap_windows: int) -> list[tuple[int, int]]:
    """Runs of firing windows, as inclusive ``(first, last)`` index pairs.

    Args:
        firing: Per-window booleans.
        min_windows: Drop a run shorter than this.
        gap_windows: Bridge a gap of at most this many quiet windows.

    Returns:
        The runs, in time order.
    """
    runs: list[tuple[int, int]] = []
    start = None
    gap = 0
    for i, hit in enumerate(firing):
        if hit:
            if start is None:
                start = i
            gap = 0
        elif start is not None:
            gap += 1
            if gap > gap_windows:
                runs.append((start, i - gap))
                start = None
    if start is not None:
        runs.append((start, len(firing) - 1))
    return [(lo, hi) for lo, hi in runs if hi - lo + 1 >= min_windows]


def band_extent(document: dict, spec) -> tuple[float, float]:
    """The frequency band a box should be drawn across.

    A detection in siar is two-dimensional, but an evolved metric is a scalar over a whole window
    — it does not, by itself, say *where* in the spectrum it fired. What it does say is which
    features it reads, and most of those are named for a band. So the box spans the union of the
    bands the model actually looks at, which is both honest and useful: it is exactly the region of
    the spectrogram the answer depends on.

    Falls back to the full analysed range when only shape features are read, which have no single
    frequency to point at.
    """
    edges = document.get("box_band") or {}
    if edges:
        return float(edges["fmin"]), float(edges["fmax"])
    return float(max(0.0, spec.fmin_hz)), float(spec.f_high)


def peak_stats(block: np.ndarray, grid, fmin: float, fmax: float) -> tuple[float, int, float]:
    """Brightest frequency, active cell count and peak contrast inside a box's band.

    These are the diagnostic fields siar-app's viewer reads. They describe the *spectrogram* under
    the box rather than the model: the model already decided there is something here, these say
    what it looks like.
    """
    hz_per_bin = float(grid.sample_rate) / float(grid.fft) if grid.fft else 0.0
    if hz_per_bin <= 0 or block.size == 0:
        return 0.0, 0, 0.0
    lo = max(0, int(fmin / hz_per_bin))
    hi = min(block.shape[1], int(fmax / hz_per_bin) + 1)
    if hi <= lo:
        return 0.0, 0, 0.0

    sub = np.asarray(block[:, lo:hi], dtype=np.float64)
    db = np.log1p(sub)
    med = float(np.median(db))
    mad = float(np.median(np.abs(db - med))) or 1e-9
    # 1.4826 * MAD estimates sigma for normally distributed data without letting the loud cells
    # the box exists because of inflate the background they are measured against.
    sigma = 1.4826 * mad
    z = (db - med) / sigma
    peak = int(np.argmax(sub)) % sub.shape[1]
    return (
        float((lo + peak) * hz_per_bin),
        int(np.count_nonzero(z > 3.0)),
        float(np.max(z)),
    )
