# Vixen Intelligence c.2026
"""Recovering a window's time-domain RMS from the magnitude grid.

This module is **copied verbatim into every generated model package** (see
:mod:`siarbuild.vendor`), so it must import nothing but numpy. There is one implementation and
both halves of the parity test run it.

The problem it solves is the only real seam in this package. brahma scales each analysis window
to unit RMS *before* the STFT — ``FeatureSpec.rms_normalise``, which its own documentation calls
"the single most consequential default in the library", because without it a target class that is
merely louder than the background is separated by ``frame_energy_mean`` in generation 1 and the
search learns nothing about the signature. A siar-app algorithm never sees samples; its entire
input is a ``FrameGrid`` of magnitudes. So the scale the model was trained under has to be
reconstructed from spectra.

Scaling samples by ``1/r`` scales every ``|X|`` by ``1/r``, so only ``r`` is needed, and Parseval
gives each frame's windowed energy exactly::

    sum_n (x[n] w[n])^2  =  (|X_0|^2 + 2 sum_{k=1}^{N/2-1} |X_k|^2 + |X_{N/2}|^2) / N

Dividing that by ``sum_n w[n]^2`` turns it into a mean energy density around the frame's centre.
Interpolating those densities across the window and averaging gives ``r^2``.

**Which frames are used is the whole trick, and getting it wrong is expensive.** The obvious
choice is the frames belonging to the window — and it fails badly. A Hann window is zero at its
ends, so a sample near the analysis window's edge contributes almost nothing to any frame inside
it. Energy there is close to invisible. Measured on a silence-to-tone step landing 2560 samples
from a window boundary, an estimator restricted to the window's own frames missed the RMS by
**56%**.

The fix is that the scanner is handed the *whole recording's* grid, not one window's worth. Frames
that start before the window or extend past it still overlap it, and they see its edges with full
Hann weight. Reading ``n_fft // hop`` frames of context either side means every sample of the
window is covered by a frame that measures it properly, and the same step case comes back at
**1.8e-3**. Every signal tested improves; nothing regresses.

What remains is a genuine approximation — energy density is interpolated between frame centres,
so structure faster than the hop is smoothed — and it is measured rather than asserted, by
``tests/test_rms.py`` on synthetic signals and by ``siar-build verify`` on the client's own audio.
The residual is not zero and is not claimed to be. If it ever matters for a corpus, the documented
escape is ``BuildConfig(rms_normalise=False)``: it removes the step from both sides, at the cost
of exposing the search to the energy dominance the flag exists to prevent — which brahma's own
unseen report and label-shuffle control will then show.
"""
from __future__ import annotations

import numpy as np

__all__ = ["WindowNormaliser", "hann"]


def hann(n: int) -> np.ndarray:
    """Symmetric Hann window of length ``n``.

    Duplicated from ``brahma_intelligence.audio.stft.hann`` rather than imported, because this
    module ships inside a generated package that must run with only numpy present. It is the same
    ``n - 1`` symmetric convention siar-app's ``dsp/windows.py`` uses, which matters: the periodic
    ``n`` divisor scipy defaults to differs by one sample of taper, enough to move a box by a bin
    when a cell sits on its threshold. ``tests/test_rms.py`` asserts this equals both of them.

    Args:
        n: Window length.

    Returns:
        ``(n,)`` float64.
    """
    if n <= 1:
        return np.ones(max(1, n), dtype=np.float64)
    i = np.arange(n, dtype=np.float64)
    return 0.5 * (1.0 - np.cos(2.0 * np.pi * i / (n - 1)))


class WindowNormaliser:
    """Reconstructs the per-window RMS scale for one fixed geometry.

    The geometry never changes within a model, so everything that depends only on it is built
    once here and reused for every window of every recording.

    Attributes:
        n_fft: STFT window length in samples.
        hop: STFT hop in samples.
        window_samples: Length of one analysis window in samples.
        frames: STFT frames inside one analysis window.
        context: Frames of overlap read either side of a window. ``n_fft // hop``, which is how
            many frames it takes for the Hann taper to have passed over a given sample entirely.
    """

    __slots__ = ("n_fft", "hop", "window_samples", "frames", "context", "_frame_norm", "_offsets")

    def __init__(self, n_fft: int, hop: int, window_samples: int, frames: int) -> None:
        self.n_fft = int(n_fft)
        self.hop = int(hop)
        self.window_samples = int(window_samples)
        self.frames = int(frames)
        self.context = max(1, self.n_fft // self.hop)

        # sum_n w[n]^2 — converts a frame's windowed energy into a mean energy density.
        self._frame_norm = float((hann(self.n_fft) ** 2).sum())
        # Sample positions of the analysis window, relative to its own start.
        self._offsets = np.arange(self.window_samples, dtype=np.float64)

    def frame_energies(self, magnitudes: np.ndarray) -> np.ndarray:
        """Windowed energy of each frame, exactly, by Parseval.

        Args:
            magnitudes: ``(frames, bins)`` linear ``|rfft|``, as siar-app produces them.

        Returns:
            ``(frames,)`` float64, each entry ``sum_n (x[n] w[n])**2`` for that frame.
        """
        p = np.asarray(magnitudes, dtype=np.float64) ** 2
        # rfft keeps bin 0 and, for even n_fft, the Nyquist bin once; every bin between stands
        # for a conjugate pair and counts twice.
        return (p[:, 0] + 2.0 * p[:, 1:-1].sum(axis=1) + p[:, -1]) / self.n_fft

    def rms(self, grid: np.ndarray, first_frame: int = 0) -> float:
        """The RMS of the analysis window starting at ``first_frame``.

        Args:
            grid: The **whole recording's** ``(frames, bins)`` magnitudes. Passing only the
                window's own rows still works but gives up the context frames that make this
                accurate at the window's edges — see the module docstring.
            first_frame: Row of ``grid`` the analysis window starts at.

        Returns:
            The RMS. ``0.0`` for a digitally silent window, which the caller must treat as
            "do not divide": brahma leaves silent windows unscaled rather than dividing by
            roughly nothing, and so must we.
        """
        grid = np.asarray(grid)
        lo = max(0, first_frame - self.context)
        hi = min(grid.shape[0], first_frame + self.frames + self.context)
        if hi <= lo:
            return 0.0

        energies = self.frame_energies(grid[lo:hi])
        total = float(energies.sum())
        if not np.isfinite(total) or total <= 0.0:
            return 0.0

        density = np.maximum(energies / self._frame_norm, 0.0)
        # Frame centres, in samples relative to the analysis window's start. A frame covers
        # [m*hop, m*hop + n_fft), so its energy is centred half an FFT later than it begins.
        centres = (np.arange(lo, hi, dtype=np.float64) - first_frame) * self.hop + self.n_fft / 2.0
        profile = np.interp(self._offsets, centres, density)
        return float(np.sqrt(max(0.0, float(profile.mean()))))

    def scale(self, grid: np.ndarray, first_frame: int = 0) -> float:
        """The factor to multiply the window's magnitudes by to match brahma's normalised window.

        The ``1e-9`` floor is not a tidy-up: it is the same cutoff
        ``brahma_intelligence.audio.window.slice_windows`` applies, and a silent window must be
        left at unit scale on both sides or the two frontends disagree by orders of magnitude on
        exactly the windows where dither is all there is.

        Args:
            grid: The whole recording's ``(frames, bins)`` magnitudes.
            first_frame: Row of ``grid`` the analysis window starts at.

        Returns:
            ``1 / rms``, or ``1.0`` for a window brahma would consider silent.
        """
        r = self.rms(grid, first_frame)
        return 1.0 / r if r > 1e-9 else 1.0
